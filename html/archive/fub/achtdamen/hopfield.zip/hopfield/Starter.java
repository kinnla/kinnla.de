package hopfield;

import javax.swing.JApplet;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import java.awt.Image;
import java.awt.Toolkit;
import java.net.URL;

public class Starter extends JApplet {

  // image paths
  public static final String QUEENS_IMAGE = "dame.gif";
  public static final String NORTHEAST_IMAGE = "northeast.gif";
  public static final String NORTHWEST_IMAGE = "northwest.gif";
  public static final String SOUTHEAST_IMAGE = "southeast.gif";
  public static final String SOUTHWEST_IMAGE = "southwest.gif";

  // data objects
  private QueensHopfield hopfield = null;
  private Control control = null;

  // gui objects
  private HFrame hframe = null;
  private MainPanel mainPanel = null;
  private HopfieldPanel hopfieldPanel = null;
  private ControlPanel controlPanel = null;

  // images that are preloaded
  public Image queensImage;
  public Image northeastImage;
  public Image northwestImage;
  public Image southeastImage;
  public Image southwestImage;

  // flag indicating, whether this is an applet
  private boolean isApplet = true;

  // singleton-like self reference
  public static Starter starter = new Starter();

  public Starter() {
  }

  // constructs and initializes all objects bottom-up
  public void init() {

	// load images
	if (this.isApplet) {
	  this.queensImage = this.getImage(this.getCodeBase(), QUEENS_IMAGE);
	  this.northeastImage = this.getImage(this.getCodeBase(), NORTHEAST_IMAGE);
	  this.northwestImage = this.getImage(this.getCodeBase(), NORTHWEST_IMAGE);
	  this.southeastImage = this.getImage(this.getCodeBase(), SOUTHEAST_IMAGE);
	  this.southwestImage = this.getImage(this.getCodeBase(), SOUTHWEST_IMAGE);
	}
	else {
	  this.queensImage = Toolkit.getDefaultToolkit().createImage(QUEENS_IMAGE);
	  this.northeastImage = Toolkit.getDefaultToolkit().createImage(NORTHEAST_IMAGE);
	  this.northwestImage = Toolkit.getDefaultToolkit().createImage(NORTHWEST_IMAGE);
	  this.southeastImage = Toolkit.getDefaultToolkit().createImage(SOUTHEAST_IMAGE);
	  this.southwestImage = Toolkit.getDefaultToolkit().createImage(SOUTHWEST_IMAGE);
	}

	// ask for number of queens
	String s = JOptionPane.showInputDialog("How many queens?");
	int queens = Integer.parseInt(s);

	// construct hopfield and control
	this.hopfield = new QueensHopfield(queens);
	this.control = new Control(this, this.hopfield);

	// init hopfield and control
	this.hopfield.init();
	this.control.init();

	// construct panels
	this.hopfieldPanel = new HopfieldPanel(this, this.hopfield);
	this.controlPanel = new ControlPanel(this.control, this.hopfield);
	this.mainPanel = new MainPanel(this.hopfieldPanel, this.controlPanel);

	// init Panels
	this.hopfieldPanel.init();
	this.controlPanel.init();
	this.mainPanel.init();
  }

  public void start() {

	// construct hframe
	this.hframe = new HFrame(this, "Acht Damen", this.mainPanel);
	this.hframe.init();
	this.hframe.pack();
	this.hframe.show();
  }

  public void exit() {
	this.hframe.setVisible(false);
	this.hframe.dispose();
	if (this.isApplet) {
	  Starter.starter.stop();
	}
	else {
	  System.exit(0);
	}
  }

  public void restart() {
	this.hframe.setVisible(false);
	this.hframe.dispose();
	this.init();
	this.start();
  }

  public static void main(String[] args) {
	starter.isApplet = false;
	starter.init();
	starter.start();
  }
}