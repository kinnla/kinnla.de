package hopfield;

import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.*;

public class HFrame extends JFrame {

  private MainPanel mainPanel;
  private Starter starter;

  public HFrame(Starter starter, String title, MainPanel mainPanel) {
	super(title);
	this.mainPanel = mainPanel;
	this.starter = starter;
  }

  public void init() {
	this.getContentPane().setLayout(new GridBagLayout());
	this.getContentPane().add(this.mainPanel, new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0,
		GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
	this.addWindowListener(new WindowAdapter() {
	  public void windowClosing (WindowEvent e) { HFrame.this.starter.exit(); }
	});
  }

}