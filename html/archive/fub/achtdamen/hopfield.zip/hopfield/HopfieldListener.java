package hopfield;

public interface HopfieldListener {

  public void hopfieldChanged();
}