package hopfield;

public interface ControlListener {
  public void statusChanged(short status);
}