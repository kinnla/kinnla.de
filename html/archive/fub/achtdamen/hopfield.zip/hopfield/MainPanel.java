package hopfield;

import javax.swing.*;
import java.awt.*;

public class MainPanel extends JPanel {

  private HopfieldPanel hopfieldPanel;
  private ControlPanel controlPanel;

  public MainPanel(HopfieldPanel hopfieldPanel, ControlPanel controlPanel) {
    this.hopfieldPanel = hopfieldPanel;
    this.controlPanel = controlPanel;
  }

  public void init() {
    this.setLayout(new GridBagLayout());
    this.add(this.hopfieldPanel, new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0,
        GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
    this.add(this.controlPanel, new GridBagConstraints(1, 0, 1, 1, 1.0, 1.0,
        GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
  }
}