/*
 *	ALP3 Uebungszettel Nr. 8 
 *	Aufgabe 50
 *
 *	Musterl�sung von
 *
 *	Jan F. Boldt		Boldt_AT_inf.fu-berlin.de
 *	Frank Schulze		FSchulze_AT_inf.fu-berlin.de
 *
 *
 *	Wir haben in dem Programm keine Fehler mehr finden k�nnen.
 *	Falls ihr noch Fehler findet, w�rde ich mich freuen wenn ihr
 *	sie nicht f�r euch behaltet, sondern sie mir an Boldt_AT_....
 *	Schickt. Danke!!
 * 
 */




/*
 * CTime programmiert von Steffen Richter (steffen..@web.de)
 * Enth�lt Methoden zum speichern, �ndern und ausgeben einer abstrakten Zeitdarstellung
 * Einfachere Handhabung als die Date Klasse (kann auch weniger :-)
 * 
 * 
 * Ich habe diese Klasse einfach �bernommen, da sie mit der eigentlichen Aufgabe nichts
 * zu tun hat, und ich sie sonst auch noch selber geschrieben h�tte. :-p
 */


public class CTime implements Comparable
{
	private long tickSecond; //Anzahl der Ticks. Ein Tick pro Sekunde
	
	public CTime(){
	}

	public CTime(long ticks){
        tickSecond = ticks;
	}

	//Setzt die Anzahl der verstrichenen Sekunden
	public void setTicks(long ticks){
		this.tickSecond = ticks;
	}

	public long getTicks(){
		return this.tickSecond;
	}

	//Addiert eine Sekunde 
	public void addSecond (){
        this.tickSecond++;
	}

	//Addiert mehrere  Sekunden
	//tickSecond wird niemals negativ
	public void addSecond (long seconds){
		this.tickSecond += seconds;
	}

	//Subtrahiert eine Sekunde 
	public void subSecond (){
		if(this.tickSecond > 0)this.tickSecond--;
	}

	//Subtrahiert mehrere  Sekunden
	public void subSecond (long seconds){
		if(this.tickSecond > 0 + seconds)this.tickSecond -= seconds;
		else this.tickSecond = 0;
	}

	public String toString(){
		//86400 Sekunden in 24 Stunden

		long temp = this.tickSecond;

		//Bei 24 Stunden ist ein wrap around		
		if(temp > 86400)temp = temp % 86400;
        
        //Stunden
		long hours = 0;
		if(temp >= 3600)
		{
			hours = temp / 3600;
			temp -= hours * 3600;
		}
		//Minuten
		long minutes = 0;
		if(temp >= 60)
		{
			minutes = temp / 60;
			temp -= minutes * 60;
		}
		

		//Beim return sicher stellen das eine f�hrende 0 dargestellt wird.
		return (hours < 10 ? "0" + Long.toString(hours) : Long.toString(hours)) + ":" +
			(minutes < 10 ? "0" + Long.toString(minutes) : Long.toString(minutes)) + ":" +
			(temp < 10 ? "0" + Long.toString(temp) :  Long.toString(temp));
	}


	public int getHours(){
		long temp = this.tickSecond;
		//Bei 24 Stunden ist ein wrap around		
		if(temp > 86400)temp = temp % 86400;

		return (int)(temp / 3600);		
	}

	//Setzt die Zeit auf eine volle Stunde fest (also. z.B. 7:00:00)
	public void setHours(int hours){
		if(hours < 0)hours =0;
		this.tickSecond = hours * 3600;
		return;
	}

	public int getMinutes(){
		long temp = this.tickSecond;
		//Bei 24 Stunden ist ein wrap around		
		if(temp > 86400)temp = temp % 86400;
		
		//Stunden wegrechnen
		if(temp >= 3600)temp -= (temp / 3600) * 3600;		
		
		return (int)(temp / 60);
	}

	//Setzt die Zeit auf eine volle Minuten fest (also. z.B. 00:07:00)
	public void setMinutes(int minutes){
		if(minutes < 0)minutes =0;
		this.tickSecond = minutes * 60;
		return;
	}
	
	public int getSeconds(){
		long temp = this.tickSecond;
		//Bei 24 Stunden ist ein wrap around		
		if(temp > 86400)temp = temp % 86400;
		
		//Stunden und Minuten rausrechnen
		if(temp >= 3600)temp -= (temp / 3600) * 3600;
		if(temp >= 60)temp -= (temp / 60) * 60;
		
		return (int)temp;
	}

	public int compareTo(Object arg0){
		if(this.tickSecond < ((CTime)arg0).getTicks())return -1;
		if(this.tickSecond == ((CTime)arg0).getTicks())return 0;
		return 1;
	}

}

