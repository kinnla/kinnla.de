/*
 *	ALP3 Uebungszettel Nr. 8 
 *	Aufgabe 50
 *
 *	Musterl�sung von
 *
 *	Jan F. Boldt		Boldt_AT_inf.fu-berlin.de
 *	Frank Schulze		FSchulze_AT_inf.fu-berlin.de
 *
 *
 *	Wir haben in dem Programm keine Fehler mehr finden k�nnen.
 *	Falls ihr noch Fehler findet, w�rde ich mich freuen wenn ihr
 *	sie nicht f�r euch behaltet, sondern sie mir an Boldt_AT_....
 *	Schickt. Danke!!
 * 
 */




public class PNL {
	
	private String[] PatNameL=new String[]{
		"Sabine M�ller",		"Max Mustermann",		"Sonja Meyer",
		"Dagmar Schulz",		"Tim Braune",			"Sven Burchert",
		"Peter Herrmann",		"Doris Jankowski",		"Boris Faller",
		"Finn Neumann",			"Sarah Wernitzki",		"Angelika Bauer",
		"Martin M�ller",		"Harald Burmeister",	"Hega Thieme",
		"Rainer Schuster",		"Melanie Wollt",		"Ali Baba",
		"Kirsten Frank",		"Oliver Petersen",		"Benjamin Feller",
		"Gertrud Wendtmann",	"Susanne Engler",		"Jan Hauser",
		"Werner Holzer",		"Tina Potter",			"Kira Quartier",
		"Coco Boldt",			"Mara Sch�fer",			"Simone Sommer"
	};
	
	private int counter=0;
		
	public PNL(){

	}
	
	public String getNewPatName(){
		return this.PatNameL[(this.counter++)%this.PatNameL.length];
	}
}
