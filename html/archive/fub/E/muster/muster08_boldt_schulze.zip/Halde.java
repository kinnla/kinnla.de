/*
 *	ALP3 Uebungszettel Nr. 8 
 *	Aufgabe 50
 *
 *	Musterl�sung von
 *
 *	Jan F. Boldt		Boldt_AT_inf.fu-berlin.de
 *	Frank Schulze		FSchulze_AT_inf.fu-berlin.de
 *
 *
 *	Wir haben in dem Programm keine Fehler mehr finden k�nnen.
 *	Falls ihr noch Fehler findet, w�rde ich mich freuen wenn ihr
 *	sie nicht f�r euch behaltet, sondern sie mir an Boldt_AT_....
 *	Schickt. Danke!!
 * 
 */




import java.util.Vector;
public class Halde implements PWSchlange{

	private Vector ElemList=new Vector();

	public void einf�gen(Comparable c){
		ElemList.addElement(c);
		if(ElemList.size()>1)
		zuKlein(ElemList.size()-1);
	}
	
	public Comparable entferneMin(){
		if(ElemList.size()<=0) throw new java.util.NoSuchElementException();
		if(ElemList.size()==1) {
			Comparable temp=(Comparable)ElemList.firstElement();
			ElemList.clear();
			return temp;
			} 
			else {
				Object temp=ElemList.elementAt(0);
				ElemList.setElementAt(ElemList.lastElement(),0);
				ElemList.removeElementAt(ElemList.size()-1);
				zuGro�(0);
				return (Comparable)temp;
			}		
		
	}
	
	public void clear(){
		ElemList.clear();
	}
	
	public boolean isEmpty(){
		return ElemList.isEmpty();
	}
	
	public int size(){
		return ElemList.size();
	}
	
	

	private void vertausche(int a, int b){
		Object temp=ElemList.elementAt(a);
		ElemList.setElementAt(ElemList.elementAt(b),a);
		ElemList.setElementAt(temp,b);
	}
	
	private void zuGro�(int i){
		int n1=2*(i+1)-1;
		int n2=2*(i+1);
		if(ElemList.size()<=n1) return;
		if(ElemList.size()<=n2){
			if(((Comparable)ElemList.elementAt(i)).compareTo(ElemList.elementAt(n1))<=0) return;
				vertausche(i,n1);
				zuGro�(n1);
				return;
		}
		if(((Comparable)ElemList.elementAt(n1)).compareTo(ElemList.elementAt(n2))<=0){
			if(((Comparable)ElemList.elementAt(i)).compareTo(ElemList.elementAt(n1))<=0) return;
				vertausche(i,n1);
				zuGro�(n1);
		}	
		else {
			if(((Comparable)ElemList.elementAt(i)).compareTo(ElemList.elementAt(n2))<=0) return;
				vertausche(i,n2);
				zuGro�(n2);
		}
	}
	
	private void zuKlein(int i){
		if (i==0) return;
		int m = ((i+1)/2)-1;
		if (((Comparable)ElemList.elementAt(m)).compareTo((Comparable)ElemList.elementAt(i))<0) return;
		vertausche(i,m);
		zuKlein(m);
	}
}  // Class
