/*
 *	ALP3 Uebungszettel Nr. 8 
 *	Aufgabe 50
 *
 *	Musterl�sung von
 *
 *	Jan F. Boldt		Boldt_AT_inf.fu-berlin.de
 *	Frank Schulze		FSchulze_AT_inf.fu-berlin.de
 *
 *
 *	Wir haben in dem Programm keine Fehler mehr finden k�nnen.
 *	Falls ihr noch Fehler findet, w�rde ich mich freuen wenn ihr
 *	sie nicht f�r euch behaltet, sondern sie mir an Boldt_AT_....
 *	Schickt. Danke!!
 * 
 */




public class ANL {

	private String[] ArztNameL=new String[]{
		"Dr. Schmerz",		"Dr. Evil",
		"Dr. Feelgood",		"Dr. Hackebeil",
		"Dr. Sargtr�ger",	"Dr. Prozac",
		"Dr. Paracetamol",	"Dr. Valium",
		"Dr. Histamin",		"Dr. Fleischer"
	};
	
	private int counter=0;
		
	public ANL(){};
	
	public String getNewArztName(){
		return this.ArztNameL[(this.counter++)%ArztNameL.length];
	}
}
