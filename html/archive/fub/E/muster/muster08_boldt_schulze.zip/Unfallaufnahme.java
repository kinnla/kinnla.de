/*
 *	ALP3 Uebungszettel Nr. 8 
 *	Aufgabe 50
 *
 *	Musterl�sung von
 *
 *	Jan F. Boldt		Boldt_AT_inf.fu-berlin.de
 *	Frank Schulze		FSchulze_AT_inf.fu-berlin.de
 *
 *
 *	Wir haben in dem Programm keine Fehler mehr finden k�nnen.
 *	Falls ihr noch Fehler findet, w�rde ich mich freuen wenn ihr
 *	sie nicht f�r euch behaltet, sondern sie mir an Boldt_AT_....
 *	Schickt. Danke!!
 * 
 */




import java.util.*;
public class Unfallaufnahme {

	// Definition der Allg. Regeln
	public boolean log;
	public boolean PatVomRoeBevorzugen;
	private long my=720;
	private long lam=7200;
	private int n;
	private double p=0.15;
	
	// Definitionen der Behandlungszeitintervalle
	private long erstBehTMin=300;
	private long erstBehTMax=1200;
	private long zweitBehTMin=600;
	private long zweitBehTMax=1800;
	private long notBehTMin=1800;
	private long notBehTMax=2400;
	private long roeTMin=300;
	private long roeTMax=600;

	public CTime SprechstundeStart = new CTime(7*60*60);
	public CTime SprechstundeEnde = new CTime(11*60*60);
	public boolean inSprechstunde = false;
	public boolean EndSim= false;
	
	public LinkedList PatLNeu = new LinkedList();
	public LinkedList PatZumRoe =new LinkedList();
	public LinkedList PatLFertig = new LinkedList();
	public LinkedList PatNotfall = new LinkedList();
	
	public LinkedList[] PatLRoe;
	public Arzt[] DienstHabendeAerzte;
	public Patient[] PatSicherung;
	public Roentgenstat RoentgenS=new Roentgenstat();
	
	public Halde ereignisse =new Halde();
	
	public PNL PatNamen = new PNL();
	public ANL ArztNamen = new ANL();
	
	public int CountNot=0;
	public int CountNorm=0;


	class Patient {

		public String Name;
		public boolean erstbeh;
		public boolean verstrahlt;
		public boolean wartet;
		private int behArztNr;
		private CTime warteZeit=new CTime();
		private CTime wartetSeit=new CTime();
		
		public Patient(){
			this.Name="";
			this.erstbeh=true;
			this.verstrahlt=false;
			this.warteZeit.setTicks(0);
			this.wartetSeit.setTicks(0);
		}
	
		public Patient(String s){
			this.Name=s;
			this.erstbeh=true;
			this.verstrahlt=false;
			this.warteZeit.setTicks(0);
			this.wartetSeit.setTicks(0);
		}
		
		public void starteWarten(CTime zeit){
			this.wartet=true;
			this.wartetSeit.setTicks(zeit.getTicks());
		}
		
		public void stoppWarten(CTime zeit){
			this.wartet=false;
			this.warteZeit.addSecond(zeit.getTicks()-this.wartetSeit.getTicks());
		}
	}	//Patient


	class Arzt {
		public int ANr;
		public String Name;
		public boolean beschaeftigt;
		public boolean behandeltNotfall;
		public Patient aktPatient;
		public boolean letzteBehNot;
		private CTime warteZeit=new CTime();
		private CTime wartetSeit=new CTime();
		
		public Arzt(int nr){
			this.ANr=nr;
			this.Name="";
			this.beschaeftigt=false;
			this.behandeltNotfall=false;
			this.aktPatient=null;
			this.warteZeit.setTicks(0);
			this.wartetSeit.setTicks(0);
			this.letzteBehNot=false;
		}
	
		public Arzt(String s,int nr){
			this.ANr=nr;
			this.Name=s;
			this.beschaeftigt=false;
			this.behandeltNotfall=false;
			this.aktPatient=null;
			this.warteZeit.setTicks(0);
			this.wartetSeit.setTicks(0);
			this.letzteBehNot=false;
		}
		
		public void starteWarten(CTime zeit){
			this.beschaeftigt=false;
			this.wartetSeit.setTicks(zeit.getTicks());
		}
		
		public void stoppWarten(CTime zeit){
			this.beschaeftigt=true;
			this.warteZeit.addSecond(zeit.getTicks()-this.wartetSeit.getTicks());
		}
	}	//Arzt
	
	class Roentgenstat{
		public boolean belegt;
		public Patient aktPatient;
		private CTime warteZeit=new CTime();
		private CTime wartetSeit=new CTime();
		
		Roentgenstat(){
			this.belegt=false;
			this.aktPatient=null;
		}
		
		public void starteWarten(CTime zeit){
			this.aktPatient=null;
			this.belegt=false;
			this.wartetSeit.setTicks(zeit.getTicks());
		}
		public void stoppWarten(CTime zeit){
			this.belegt=true;
			this.warteZeit.addSecond(zeit.getTicks()-this.wartetSeit.getTicks());
		}
	}



	abstract class Ereignis implements Comparable{
	
		public CTime z=new CTime();
	
		Ereignis(CTime zeitpunkt){
			z.setTicks(zeitpunkt.getTicks());
		}

		public int compareTo(Object e){
			return (this.z.compareTo(((Ereignis)e).z));
		}
	
		abstract void bearbeite();
	}	//Ereignis


	class NeuerNotfall extends Ereignis{
		
		public Patient pat;
		
		public NeuerNotfall(Patient p, CTime Zeitpunkt){
			super(Zeitpunkt);
			this.pat=p;
		}
		
		public int compareTo(Object e){
			return (this.z.compareTo(((Ereignis)e).z));
		}
		
		public void bearbeite(){
			
			
			
			// Da alle �rzte die Behandlung unterbrechen wenn ein Notfallpatient auftaucht wird 
			// nur der 0-te Arzt kontrolliert, er steht exemplarisch f�r alle anderen.
			// (es sollte immer mindestens einen Arzt geben) ;-)
			
			this.pat.starteWarten(this.z);
			if(PatNotfall.isEmpty() & !DienstHabendeAerzte[0].behandeltNotfall){
					ereignisse.einf�gen(new NotfallBeginnBeh(this.pat,this.z));
					if (log) System.out.println(this.z.toString()+":\tNotfallpatient/in "+this.pat.Name+" kommt an. \n" +
												"\t\t\tEr/Sie wird sofort Behandelt, alle �rzte unterbrechen ihre T�tigkeit");
				}	
				else {
					PatStelltSichAn(PatNotfall,this.pat,this.z);
					if (log) System.out.println(this.z.toString()+":\tNotfallpatient/in "+this.pat.Name+" kommt an. \n" +
												"\t\t\tEr/Sie stellt (liegt) sich bei den Notfallpatienten an");
				}
				
			// Erzeugen eines Neuen Notfall Patienten mit lam in sek als mittlerer Ankunftsrate
			Patient tempPat=new Patient(PatNamen.getNewPatName());	
			CTime tempZeit=new CTime(this.z.getTicks());
			tempZeit.addSecond((long)(-lam*Math.log(Math.random())));
			if (tempZeit.compareTo(SprechstundeEnde)<=0)		
				ereignisse.einf�gen(new NeuerNotfall(tempPat, tempZeit));
			CountNot++;
		}
	}


	class NotfallBeginnBeh extends Ereignis{
		
		public Patient pat;
		
		public NotfallBeginnBeh(Patient p, CTime Zeitpunkt){
			super(Zeitpunkt);
			this.pat=p;
		}
		
		public int compareTo(Object e){ 
			return (this.z.compareTo(((Ereignis)e).z));
		}
		
		public void bearbeite(){
			this.pat.stoppWarten(this.z);
			// TODO: NotfallBeginnBeh Bearbeite

			// Die Behandlungen die schon in der Halde vorhanden sind und unterbrochen werden,
			// m�ssen sp�ter fortgesetzt werden, sie werden verschoben.
			Halde TempEreignisse=new Halde();
			Ereignis TempEreignis;
			long DauerDerNotBeh=(notBehTMin+(long)((notBehTMax-notBehTMin)*Math.random()));
			int tempint=ereignisse.size();
			for(int i=0; i<tempint; i++){
				TempEreignis=(Ereignis)ereignisse.entferneMin();
				if(	TempEreignis instanceof NeuerNotfall |
					TempEreignis instanceof NeuerPat |
					TempEreignis instanceof Betriebsschluss )
					TempEreignisse.einf�gen(TempEreignis);
					else {
						TempEreignis.z.addSecond(DauerDerNotBeh);
						TempEreignisse.einf�gen(TempEreignis);
					}
			}
			ereignisse=TempEreignisse;
			CTime tempzeit=new CTime(DauerDerNotBeh);
			CTime temp2zeit=new CTime(DauerDerNotBeh);
			tempzeit.addSecond(this.z.getTicks());
			ereignisse.einf�gen(new NotfallKommtAusBeh(this.pat,tempzeit));
			
			// Es werden alle aktuellen Patienten warten geschickt. Alle �rzte behandeln den Notfallpatienten. 
			// Die aktuellen (regul�ren) Patienten bleiben in den �rzten gesichert, damit nicht extra
			// Ereignisse wie Beginn der Behandlungsunterbrechung und die wiederaufnahme eingef�gt werden 
			// m�ssen. Falls schon vorher eine Notbehandlung stattfand


			for (int i=0; i<n; i++)	{
				DienstHabendeAerzte[i].behandeltNotfall=true;
				PatSicherung[i]=DienstHabendeAerzte[i].aktPatient;
				DienstHabendeAerzte[i].aktPatient=this.pat;
				if (PatSicherung[i]!=null){
					PatSicherung[i].starteWarten(this.z);
					if (log) System.out.println("\t\t\tDie Behandlung von "+PatSicherung[i].Name +" wird unterbrochen."); 
				}	else DienstHabendeAerzte[i].stoppWarten(this.z);
			}
			if (log)System.out.println(	this.z.toString()+":\tDie Notbehandlung von "+this.pat.Name+" beginnt. \n" +
										"\t\t\talle Behandlungen verschieben sich um "+ temp2zeit.toString()+" min.");
		}
	}
	
	
	class NotfallKommtAusBeh extends Ereignis{
		
		public Patient pat;
		
		public NotfallKommtAusBeh(Patient p, CTime Zeitpunkt){
			super(Zeitpunkt);
			this.pat=p;
		}
		
		public int compareTo(Object e){
			return (this.z.compareTo(((Ereignis)e).z));
		}
		
		public void bearbeite(){
			// TODO: NotfallKommtAusBeh Bearbeite
			for (int i=0; i<n; i++){
				DienstHabendeAerzte[i].behandeltNotfall=false;
				// Die Alten Patienten werden wieder hergestellt
				DienstHabendeAerzte[i].aktPatient=PatSicherung[i];  
				// Wenn ein Arzt einen alten Patienten hat dann h�rt dieser auf zu Warten (er wird
				// ja weiter behandelt) sonst f�ngt der Arzt an zu Warten.
				if (!DienstHabendeAerzte[i].letzteBehNot){
					if (DienstHabendeAerzte[i].aktPatient==null){
						if (PatVomRoeBevorzugen){
							if (PatLRoe[i].isEmpty()){
								if (!PatLNeu.isEmpty()) ereignisse.einf�gen(new PatBeginnBeh((Patient)PatLNeu.removeFirst(),i,new CTime(this.z.getTicks()+1)));
							}	else ereignisse.einf�gen(new PatBeginnBeh((Patient)PatLRoe[i].removeFirst(),i,new CTime(this.z.getTicks()+1)));
						} else ereignisse.einf�gen(new PatBeginnBeh((Patient)PatLRoe[i].removeFirst(),i,new CTime(this.z.getTicks()+1)));
						DienstHabendeAerzte[i].starteWarten(this.z);
					}	else DienstHabendeAerzte[i].aktPatient.stoppWarten(this.z);
				}
				DienstHabendeAerzte[i].letzteBehNot=true;
			}
			if (!PatNotfall.isEmpty()) ereignisse.einf�gen(new NotfallBeginnBeh((Patient)PatNotfall.removeFirst(),this.z));
			if (log) System.out.println(this.z.toString()+":\tDie Notbehandlung von "+ this.pat.Name+ " ist Beendet.");
			
			// Sichern des Patienten f�r die Statistik
			PatLFertig.addLast(this.pat);
			
			checkEndSim();
			if (EndSim) for (int i=0; i<n; i++)
				DienstHabendeAerzte[i].stoppWarten(this.z);
		
		}
	}


	class NeuerPat extends Ereignis{
	
		public Patient pat;

		public NeuerPat(Patient p, CTime ZeitPunkt){
			super(ZeitPunkt);
			this.pat=p;
		}

		public int compareTo(Object e){
			return (this.z.compareTo(((Ereignis)e).z));
		}
	
	
		public void bearbeite(){
			CountNorm++;
			boolean freierArztgefunden=false;
			Patient tempPat=new Patient(PatNamen.getNewPatName());
			CTime tempZeit=new CTime(this.z.getTicks());
			tempZeit.addSecond((long)(-my*Math.log(Math.random())));
			
			for(int i=0; i<n; i++){
				if (!DienstHabendeAerzte[i].beschaeftigt){
					freierArztgefunden=true;
					ereignisse.einf�gen(new PatBeginnBeh(this.pat,i,this.z));
					if (log) System.out.println(this.z.toString()+":\tPatient/in "+this.pat.Name+" kommt an. \n" +						"\t\t\tEr/Sie wird sofort von "+DienstHabendeAerzte[i].Name+" Behandelt.");
					break;	
				}
			}
			if (!freierArztgefunden){
				PatStelltSichAn(PatLNeu,this.pat,this.z);			
				if (log) System.out.println(this.z.toString()+":\tPatient/in "+this.pat.Name+" kommt an. \n" +					"\t\t\tEr/Sie Stellt sich bei den Neuen Patienten an. " );
			}
			if (tempZeit.compareTo(SprechstundeEnde)<=0)		
			ereignisse.einf�gen(new NeuerPat(tempPat, tempZeit));
			this.pat.starteWarten(this.z);	
		}
	} //neuerPat
	
	
	
	
	
	class PatBeginnBeh extends Ereignis{
		
		public int ANr;
		public Patient pat;
		
		PatBeginnBeh(Patient p,int nr,CTime zeitpunkt){
			super(zeitpunkt);
			this.ANr=nr;
			this.pat=p;
		}

		public int compareTo(Object e){
			return (this.z.compareTo(((Ereignis)e).z));
		}
	
		public void bearbeite(){
			DienstHabendeAerzte[this.ANr].aktPatient=this.pat;
			DienstHabendeAerzte[this.ANr].stoppWarten(this.z);
			this.pat.behArztNr=ANr;
			this.pat.stoppWarten(this.z);
			if (this.pat.erstbeh){
				CTime tempZeit=new CTime(this.z.getTicks());
				tempZeit.addSecond(erstBehTMin+(long)((erstBehTMax-erstBehTMin)*Math.random()));
				ereignisse.einf�gen(new PatientKommtAusBeh(this.pat,tempZeit));
				if (log) System.out.println(this.z.toString()+":\tErstbehandlung von "+this.pat.Name+" bei "+DienstHabendeAerzte[this.ANr].Name+" beginnt.");
			}
			else {	CTime tempZeit=new CTime(this.z.getTicks());
					tempZeit.addSecond(zweitBehTMin+(long)((zweitBehTMax-zweitBehTMin)*Math.random()));
					ereignisse.einf�gen(new PatientKommtAusBeh(this.pat,tempZeit));
					if (log) System.out.println(this.z.toString()+":\tZweitbehandlung von "+this.pat.Name+" bei "+DienstHabendeAerzte[this.ANr].Name+" beginnt.");
			}							
									
		}
	}	// PatBeginnBeh	
	
	
	
	
	
	
	class PatientKommtAusBeh extends Ereignis{
		
		private Patient pat;
		
		public PatientKommtAusBeh(Patient p,CTime zeitpunkt){
			super(zeitpunkt);
			this.pat=p;
		}

		public int compareTo(Object e){
			return (this.z.compareTo(((Ereignis)e).z));
		}
	
		public void bearbeite(){
			DienstHabendeAerzte[this.pat.behArztNr].beschaeftigt=false;
			if(this.z.compareTo(SprechstundeEnde)<1)
				DienstHabendeAerzte[this.pat.behArztNr].starteWarten(this.z);
				
			if (!this.pat.erstbeh){
				if (log) System.out.println(this.z.toString()+":\tPatient/in "+this.pat.Name+" kommt von der zweiten Behandlung. \n\t\t\tEr/Sie Verl�sst das Krankenhaus.");
				if (PatLFertig.isEmpty()) PatLFertig.addFirst(this.pat);
					else PatLFertig.addLast(this.pat);
			}else{
				this.pat.erstbeh=false;
				if (p>=Math.random()){
					if (log) System.out.println(this.z.toString()+":\tPatient/in "+this.pat.Name+" kommt von der ersten Behandlung. \n\t\t\tEr/Sie Verl�sst das Krankenhaus.");
					if (PatLFertig.isEmpty()) PatLFertig.addFirst(this.pat);
						else PatLFertig.addLast(this.pat);
				} else {ereignisse.einf�gen(new PatMussZumRoe(this.pat,this.z));
						if (log) System.out.println(this.z.toString()+":\tPatient/in "+this.pat.Name+" kommt von der ersten Behandlung. \n\t\t\tEr/Sie muss zum Roentgen.");} 
			}
			if(PatVomRoeBevorzugen && !PatLRoe[this.pat.behArztNr].isEmpty())
				 ereignisse.einf�gen(new PatBeginnBeh((Patient)PatLRoe[this.pat.behArztNr].removeFirst(),this.pat.behArztNr,this.z));
			else if (!PatLNeu.isEmpty()) ereignisse.einf�gen(new PatBeginnBeh((Patient)PatLNeu.removeFirst(),this.pat.behArztNr,this.z));
			DienstHabendeAerzte[this.pat.behArztNr].starteWarten(this.z);
			DienstHabendeAerzte[this.pat.behArztNr].letzteBehNot=false;
			checkEndSim();
			if (EndSim) for (int i=0; i<n; i++)
							DienstHabendeAerzte[this.pat.behArztNr].stoppWarten(this.z);
							
		}
	}	//PatKommtAusBeh



	class PatMussZumRoe extends Ereignis{
	
		public Patient pat;
	
		public PatMussZumRoe(Patient p,CTime zeitpunkt){
			super(zeitpunkt);
			this.pat=p;
		}

		public int compareTo(Object e){
			return (this.z.compareTo(((Ereignis)e).z));
		}
	
		public void bearbeite(){
			if(PatZumRoe.isEmpty()&&!RoentgenS.belegt){
				this.pat.starteWarten(this.z);
				ereignisse.einf�gen(new PatWirdGeroengt(this.pat,this.z));
				if (log) System.out.println(this.z.toString()+":\tPatient/in "+this.pat.Name+" wird sofort Geroengt.");
				}	
				else {
					PatStelltSichAn(PatZumRoe,this.pat,this.z);
					if (log) System.out.println(this.z.toString()+":\tPatient/in "+this.pat.Name+" stellt sich an der Roentgenschlange an.");
				}
 
		} //
	}	//PatMussZumRoe


	class PatWirdGeroengt extends Ereignis{
	
		public Patient pat;
	
		public PatWirdGeroengt(Patient p,CTime zeitpunkt){
			super(zeitpunkt);
			this.pat=p;
		}

		public int compareTo(Object e){
			return (this.z.compareTo(((Ereignis)e).z));
		}
	
		public void bearbeite(){
			CTime tempZeit=new CTime(this.z.getTicks());
			tempZeit.addSecond(roeTMin+(long)((roeTMax-roeTMin)*Math.random()));
			RoentgenS.stoppWarten(this.z);
			this.pat.stoppWarten(this.z);
			ereignisse.einf�gen(new PatFertigMRoe(this.pat,tempZeit));
			if (log) System.out.println(this.z.toString()+":\tRoentgenuntersuchung von "+this.pat.Name+" beginnt.");
			
 
		}
	}	//PatWirdGeroengt
	
	
	class PatFertigMRoe extends Ereignis{
	
		public Patient pat;
	
		public PatFertigMRoe(Patient p,CTime zeitpunkt){
			super(zeitpunkt);
			this.pat=p;
		}

		public int compareTo(Object e){
			return (this.z.compareTo(((Ereignis)e).z));
		}
	
		public void bearbeite(){
			
			CTime tempZeit=new CTime(this.z.getTicks());
			tempZeit.addSecond(roeTMin+(long)((roeTMax-roeTMin)*Math.random()));
			
			if (!PatZumRoe.isEmpty())
				ereignisse.einf�gen(new PatWirdGeroengt((Patient)PatZumRoe.removeFirst(),this.z));
			
			if (log) System.out.println(this.z.toString()+":\tRoentgenuntersuchung von "+this.pat.Name+" beendet.");
			if (PatVomRoeBevorzugen){
				if (!DienstHabendeAerzte[this.pat.behArztNr].beschaeftigt)
					ereignisse.einf�gen(new PatBeginnBeh(this.pat,this.pat.behArztNr,this.z));
					else{ 
						PatStelltSichAn(PatLRoe[this.pat.behArztNr],this.pat,this.z);
						if (log)System.out.println("\t\t\tEr/Sie stellt sich an der Priorit�tsschlange von "+
								DienstHabendeAerzte[this.pat.behArztNr].Name+" an.");
					}

			} else {
				if (PatLNeu.isEmpty()){
					boolean alleBelegt=true;
					for (int i=0;i<n;i++){
						if (!DienstHabendeAerzte[i].beschaeftigt){
							alleBelegt=false;
							ereignisse.einf�gen(new PatBeginnBeh(this.pat,i,this.z));
							break;
						}
					}
					if(alleBelegt){
						PatStelltSichAn(PatLNeu,this.pat,this.z);
						if (log)System.out.println("\t\t\tEr/Sie stellt sich wieder normal an.");
					}
				}else {
					PatStelltSichAn(PatLNeu,this.pat,this.z);
					if (log)System.out.println("\t\t\tEr/Sie stellt sich wieder normal an.");
					
				} 
		
			}
			RoentgenS.starteWarten(this.z);
			checkEndSim();	
			if (EndSim) RoentgenS.stoppWarten(this.z);
		}
	}	//PatFertigMRoe
	


	
	
	class Betriebsstart extends Ereignis{
		
		public Betriebsstart(CTime zeitpunkt){
			super(zeitpunkt);
		}

		public int compareTo(Object e){
			return (this.z.compareTo(((Ereignis)e).z));
		}
	
		public void bearbeite(){
			inSprechstunde=true;
			if(log)System.out.println(this.z.toString()+":\tANFANG DER SPRECHSTUNDE!!\n");
			
			for(int i=0; i<n; i++){
				DienstHabendeAerzte[i].starteWarten(this.z);
				if (log) System.out.println(DienstHabendeAerzte[i].Name + " wartet auf ersten Patienten.");
			}
			RoentgenS.starteWarten(new CTime(this.z.getTicks()));
			if (log) System.out.println("Die Roentgenstation Wartet auf Patienten\n\n");
			Patient tempPat=new Patient(PatNamen.getNewPatName());
			CTime tempZeit=new CTime(this.z.getTicks());
			tempZeit.addSecond((long)(-my*Math.log(Math.random())));
			ereignisse.einf�gen(new NeuerPat(tempPat, tempZeit));
			
			Patient tempNotPat=new Patient(PatNamen.getNewPatName());
			CTime tempNotZeit=new CTime(this.z.getTicks());
			tempZeit.addSecond((long)(-lam*Math.log(Math.random())));
			ereignisse.einf�gen(new NeuerNotfall(tempNotPat, tempNotZeit));	
		}
	}	// BetriebsStart
	
	
	
	
	class Betriebsschluss extends Ereignis{
		
		public Betriebsschluss(CTime zeitpunkt){
			super(zeitpunkt);
		}

		public int compareTo(Object e){
			return (this.z.compareTo(((Ereignis)e).z));
		}
	
		public void bearbeite(){
			inSprechstunde=false;
			if(log)System.out.println(this.z.toString()+":\tENDE DER SPRECHSTUNDE!!\n" +				"\t\t\tAlle schon angenommenen Patienten werden weiter Behandelt.");
			checkEndSim();
			if (EndSim)
				for (int i=0; i<n;i++)
					DienstHabendeAerzte[i].stoppWarten(this.z);
		}
		
	}	//Betriebsschluss




	
	public Unfallaufnahme(boolean logAll, boolean RoeBevorz, int AnzAerzte){
		this.log=logAll;
		this.PatVomRoeBevorzugen=RoeBevorz;
		this.n=AnzAerzte;
		
		PatLRoe = new LinkedList[n];
		for(int i=0;i<n;i++)
			PatLRoe[i]=new LinkedList();
		DienstHabendeAerzte=new Arzt[n];
		PatSicherung=new Patient[n];
		
		for(int i=0; i<this.n;){
			DienstHabendeAerzte[i]=new Arzt(ArztNamen.getNewArztName(),i);
			i++;
		}	
		ereignisse.einf�gen(new Betriebsschluss(SprechstundeEnde));	
		ereignisse.einf�gen(new Betriebsstart(SprechstundeStart));	
		
		while (!ereignisse.isEmpty()) {
			Ereignis e = (Ereignis)(ereignisse.entferneMin());
			e.bearbeite(); 
		}
		System.out.print(Statistik());
	
	

	} //Unfallaufnahme

	
	
	public void checkEndSim(){
		boolean alleAerztefrei=true;
		for(int i=0; i<n; i++)
			if (DienstHabendeAerzte[i].beschaeftigt) alleAerztefrei=false;
		
		EndSim=PatNotfall.isEmpty() && PatLNeu.isEmpty() && PatZumRoe.isEmpty() && alleAerztefrei && !RoentgenS.belegt && !inSprechstunde && ereignisse.isEmpty();
	}
	
	public String Statistik(){
		CTime GesWZeitAe=new CTime(0);
		CTime GesWZeitPat=new CTime(0);
		String EinzelWzeitAe=new String();
		String EinzelWzeitPat=new String();
		Patient[] PatA=new Patient[PatLFertig.size()];

		if (log)System.out.println("\n\n\tEnde der Simulation.\n\tAlle �rzte und die Roengenstation h�ren auf zu warten.");

		for(int i=0;i<PatA.length;i++)
			PatA[i]=(Patient)PatLFertig.removeFirst();
		
		for(int i=0;i<n;i++){
			GesWZeitAe.addSecond(DienstHabendeAerzte[i].warteZeit.getTicks());
			EinzelWzeitAe+="\t\t"+DienstHabendeAerzte[i].Name+": "+DienstHabendeAerzte[i].warteZeit.toString()+"\n";
		}
		for(int i=0;i<PatA.length;i++){
			GesWZeitPat.addSecond(((Patient)PatA[i]).warteZeit.getTicks());
			EinzelWzeitPat+="\t\t"+((Patient)PatA[i]).Name+": "+((Patient)PatA[i]).warteZeit.toString()+"\n";	
		}
		String ausgabe=new String();
		if (log) {ausgabe =	"\n\tEinzelne Wartezeiten der �rzte:\n"+EinzelWzeitAe+
							"\n\tGesamtwartezeit der �rzte: "+GesWZeitAe.toString()+   
							"\n\n\tGesamtwartezeit der R�ntgenstation: "+RoentgenS.warteZeit+
							"\n\n\tEinzelne Wartezeiten der Patienten: \n"+EinzelWzeitPat+
							"\n\tAnzahl der Patienten: "+CountNorm+
							"\n\tAnzahl der Notf�lle: "+CountNot+
							"\n\tGesamtwartezeit der Patienten: "+GesWZeitPat.toString()+"\n\n";
			}
			else {ausgabe = "\n\tAnzahl der Patienten: "+CountNorm+
							"\n\tAnzahl der Notf�lle: "+CountNot+
							"\n\tGesamtwartezeit der �rzte: "+GesWZeitAe.toString()+
							"\n\tGesamtwartezeit der R�ntgenstation: "+RoentgenS.warteZeit+
							"\n\tGesamtwartezeit der Patienten: "+GesWZeitPat.toString()+"\n\n";
			}
		return ausgabe;
	}
	
	public void PatStelltSichAn(LinkedList l,Patient p, CTime zeit){
		p.starteWarten(new CTime(zeit.getTicks()));
		if (l.isEmpty()) l.addFirst(p);
			else l.addLast(p); 
	}
	
	
	public static void main(String[] args){
		System.out.println("\nStart von einer Simulation mit Details.\nBehandlungsregel: Patienten vom Roentgen bevorzugen.\n");
		new Unfallaufnahme(true,true,3);
			
	}
	
	
	
} // Programm
