
import Alp3U3.Simulation;


/**
 * ALP3 Uebung3
 * Marian Schwarz, Valentin Weckerle
 *
 * Doctor Class
 */
public class Alp3U3
{
	/**
	 * main method for testing/debuging only
	 * @param args
	 */
	public static void main (String[] args)
	{
		//initialize the simulation
		Simulation s = new Simulation(30*60, 0.15f, 2, 4*60*60, Simulation.SIMULATION_DOCTYPE_PUBLICDOC, Simulation.SIMULATION_XRAYTYPE_ONLYONCE);
		//start the simulation
		s.run();
	}
}
