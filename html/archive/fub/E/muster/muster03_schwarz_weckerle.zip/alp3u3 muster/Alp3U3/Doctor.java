
package Alp3U3;

import Alp3U3.Events.EventEndPatientTreatment;
import java.util.LinkedList;


/**
 * ALP3 Uebung3
 * Marian Schwarz, Valentin Weckerle
 *
 * Doctor Class
 */
public class Doctor
{
	//time this doctor had nothing to do
	private int playingPoolSince = -1;
	//is this doctor busy?
	private boolean playingPool = true;
	//private patients which have been assigned to this doctor and have now
	//returned from their xray treatment
	private LinkedList waitingVictims = null;
	//statistic counter to keep track of the maximum queue length seen
	private int maxQueueLength = 0;
	//name of this doctor
	private int docId = 0;

	//timer values
	private int minTortureTime = 5*60;
	private int maxTortureTime = 20*60;
	private int minTortureTimeXRay = 10*60;
	private int maxTortureTimeXRay = 30*60;

	/**
	 * creates a new doctor instance and initializes all needed fields
	 * a new doctor is by default playing pool untill kicked
	 * @param docId new name for this doctor
	 */
	public Doctor (int docId)
	{
		this.docId = docId;
		playingPoolSince = Simulation.curtime;
		playingPool = true;
		waitingVictims = new LinkedList();
		initComments();
	}

	/**
	 * tell this doctor that there is nothing to do and that a game of pool should begin
	 */
	public void startPoolGame ()
	{
		playingPoolSince = Simulation.curtime;
		playingPool = true;
		Simulation.log("Doctor "+this+" tries to improve his angle calculation abilities by playing a game of pool.");
		//TODO: add pool events to display highscores and ingame events :o)
	}

	/**
	 * work is waiting, this doctor should stop the current game of pool
	 * and start working
	 */
	public void endPoolGame ()
	{
		//update doc waiting time stats
		int poolDuration = Simulation.curtime - playingPoolSince;
		Simulation.statDocWaited(poolDuration);

		//show message
		Simulation.log(getEndOfPoolComment()+" "+Simulation.formatTime(poolDuration));

		playingPoolSince = -1;
		playingPool = false;

		//start working
		beginWork(); //yeah right
	}

	/**
	 * the doctor will check for waiting patients.
	 * the personal victim queue has precedence, if it's empty the main reception queue is checked
	 * if no patient is available the doctor starts a new game of pool
	 * if a new patient is found it's torture will begin immediately
	 */
	public void beginWork ()
	{
		//check if we have some of our own private victims waiting
		Patient victim = getNextPrivateVictim();

		//ok, now try to get a fresh victim from the reception
		if (victim == null)
			victim = Simulation.receptionDesk.getNextPatient();

		if (victim == null)
			//hm? ah, what the heck, let's finish that game of pool
			startPoolGame();

		else //ok, let's get funky
			torture(victim);

	}

	/**
	 * this is called by the EndPatientTreatment event once the current treatment is finished
	 * the doctor will now have to decide what to do with this patient
	 * @param victim the current patient
	 */
	public void endTorture (Patient victim)
	{
		victim.log("end treatment by: "+this+", duration: "+Simulation.formatTime(Simulation.curtime - victim.getInTreatmentSince()));

		if (
				( //if we're in ONLYONCE mode, don't allow multiple xray treatments
					(Simulation.xraytype != Simulation.SIMULATION_XRAYTYPE_ONLYONCE)
					||
		            (!victim.getWasXray())
				)
				&&
		        (Math.random() > Simulation.probabilityOfLeave)
		)
		{
			//ok, let's xray this victim, ok we might check victim.wasXray() or even
			//keep some radiation counters, but oh well, he'll just have to hold together.
			//ps probability of this victim being xrayed 10 times in a row is ~ 20%  }:o)
			Simulation.log("Doctor "+this+" finished his torture of patient "+victim+". The patient will need an XRay treatment.");
			Simulation.xray.newPatient(victim);
		}
		else
		{
			//damn, we'll have to find another test subject for that nasty new treatment
			//we just thought about
			Simulation.log("Doctor "+this+" finished his torture of patient "+victim+". The patient will be dismissed.");
			//send the patient home
			victim.leave();
		}

		//look for our next victim
		beginWork();
	}

	/**
	 * called by Patient once he returns from an xray treatment if we are his personal doctor
	 * and the simulation is in SIMULATION_DOCTYPE_PRIVATEDOC mode
	 * @param victim returning patient
	 */
	public void newPrivateVictim (Patient victim)
	{
		//add the victim to our personal queue
		victim.startWaiting("doctor");
		waitingVictims.add(victim);

		//update stats
		if (waitingVictims.size() > maxQueueLength)
			maxQueueLength = waitingVictims.size();

		//check if we're currently idle, if so, start working
		if (playingPool)
			endPoolGame();
	}

	/**
	 * returns the name of this doctor
	 * @return name of the doctor
	 */
	public String toString ()
	{
		return "D-"+docId;
	}

	/**
	 * returns whether this doctor is playing pool ATM
	 * @return pool status
	 */
	public boolean isPlayingPool ()
	{
		return playingPool;
	}

	/**
	 * returns the highest reached personal queue length
	 * @return highest queue length reached
	 */
	public int getMaxQueueLength ()
	{
		return maxQueueLength;
	}

	/**
	 * returns the number of patients currently waiting in the personal queue of this
	 * doctor
	 * @return personal queue size
	 */
	public int getWaitingRoomSize ()
	{
		return waitingVictims.size();
	}

	/**
	 * starts the torture of a given patient
	 * @param victim patient to torture
	 */
	private void torture (Patient victim)
	{
		int tortureDuration;

		Simulation.log("Doctor "+this+" began his torture of patient "+victim);

		victim.stopWaiting("doctor");
		victim.log("begin treatment by: "+this);

		//check if this is the first treatment or a follow up
		if (victim.getWasXray())
			//ok, we know this one, let's earn some more money
			tortureDuration = (int)(minTortureTimeXRay+(maxTortureTimeXRay-minTortureTimeXRay)*Math.random());
		else
			tortureDuration = (int)(minTortureTime+(maxTortureTime-minTortureTime)*Math.random());

		//ok, let's claim this test subject, if we're in the corresponding mode
		if (Simulation.doctype == Simulation.SIMULATION_DOCTYPE_PRIVATEDOC)
			victim.assignDoctor(this);

		//create EndPatientTreatment event to trigger once this torture is finished
		Simulation.events.insert(new EventEndPatientTreatment(Simulation.curtime + tortureDuration, this, victim));
	}

	/**
	 * returns the next victim waiting in the private queue of this doctor and removes the
	 * victim from the queue
	 * @return next patient or null
	 */
	private Patient getNextPrivateVictim ()
	{
		if (waitingVictims.isEmpty())
			return null;

		return (Patient)waitingVictims.removeFirst();
	}

	//important statistic information
	private String[] endPoolComments = null;
	private void initComments ()
	{
		endPoolComments = new String[] {
			"Doctor "+this+" stopped playing.",
			"Doctor "+this+" just broke his all time highscore.",
			"Doctor "+this+" had a remarkable long game of pool.",
			"Doctor "+this+" just finished his game of pool.",
			"Doctor "+this+" was unexpectedly able to hit it four times.",
			"Doctor "+this+" mumbles about the inconvenience of demanding patients.",
			"Doctor "+this+" takes his billiard cue with him.",
			"Doctor "+this+" was interrupted while working on his world domination plans.",
			"Doctor "+this+" rages about all the interruptions.",
			"Doctor "+this+" brakes his cue and hates all the world.",
			"Doctor "+this+" makes evil plans for his next victim.",
			"Doctor "+this+" mumbles about axes, chainsaws, hammers, ...",
			"Doctor "+this+" hasn't even finished his coffee.",
			"Doctor "+this+" would like to play more, but couldn't"
		};
	}

	/**
	 * select random pool comment
	 * @return pool comment
	 */
	private String getEndOfPoolComment ()
	{
		int i = (int)(Math.random()*endPoolComments.length-1);
		return endPoolComments[i];
	}
}
