
package Alp3U3;

import java.util.LinkedList;
import java.util.NoSuchElementException;


/**
 * ALP3 Uebung3
 * Marian Schwarz, Valentin Weckerle
 *
 * Reception Class
 */
public class Reception
{
	//main queue for patient
	private LinkedList waitingRoom = null;
	//patient number sequence which is used to assign a unique id to each new patient
	private int patientNumberSequence = 1;
	//array of active doctors
	private Doctor[] staffRoom = null;
	private int maxQueueLength = 0;

	/**
	 * initialize the reception object
	 * new doctors are spawned
	 */
	public Reception ()
	{
		waitingRoom = new LinkedList();

		//populate staff room
		staffRoom = new Doctor[Simulation.numberOfDoctors];
		for (int i=0; i < staffRoom.length; i++)
		{
			staffRoom[i] = new Doctor(i+1);
		}
	}

	/**
	 * called once a new patient arrives at the reception desk, depending on the current mode of
	 * the simulation those are either only the new patients or also those who return from the
	 * xray treatment
	 * @param p new patient
	 */
	public void newPatient (Patient p)
	{
		//check if known patient
		if (p.getPatId() == 0)
		{
			//brand new victim
			p.givePatientNumber(patientNumberSequence++);

			Simulation.log("New Patient "+p+" arrived at the reception desk, "+waitingRoom.size()+" other Patients are waiting.");
		}

		//check if the patient will be the only one in the waitingRoom
		boolean isOnlyPatient = waitingRoom.isEmpty();

		waitingRoom.add(p);
		p.startWaiting("doctor");

		//update stats
		if (waitingRoom.size() > maxQueueLength)
			maxQueueLength = waitingRoom.size();

		//ok, the waiting room was empty before this patient showed up
		//it's very likely that all our doctors are playing pool in the
		//staff room, so we'll have to kick some butt :o)
		if (isOnlyPatient)
		{
			Doctor lameass = getNextLameass();
			kick(lameass);
			/*
				Hier k�nnte man nat�rlich argumentieren, dass ein lameass
				seine kick routine selber mitbringen sollte.
				Nach reichlicher �berlegung haben wir uns jedoch dazu entschlossen
				diese anspruchsvolle aufgabe dem rezeptionspersonal zu �berlassen :o)
			*/
		}
	}

	/**
	 * returns the next waiting patient from the main queue and removes it from the queue
	 * @return next patient in line or null if queue is empty
	 */
	public Patient getNextPatient ()
	{
		try
		{
			return (Patient)waitingRoom.removeFirst();
		}
		catch (NoSuchElementException e)
		{
			return null;
		}
	}

	/**
	 * @return highest queue length seen
	 */
	public int getMaxQueueLength ()
	{
		return maxQueueLength;
	}

	/**
	 * checks all doctors and returns the highest personal queue length found
	 * @return highest personal queue length
	 */
	public int getMaxPersonalQueueLength ()
	{
		int max = 0;

		for(int i=0; i < staffRoom.length; i++)
			if (staffRoom[i].getMaxQueueLength() > max)
				max = staffRoom[i].getMaxQueueLength();

		return max;
	}

	/**
	 * @return number of patients waiting
	 */
	public int getWaitingRoomSize ()
	{
		return waitingRoom.size();
	}

	/**
	 * check the staff room for pool playing doctors and pick one
	 * @return first idle doctor found or null if all doctors are busy
	 */
	private Doctor getNextLameass ()
	{
		for(int i=0; i < staffRoom.length; i++)
			if (staffRoom[i].isPlayingPool())
				return staffRoom[i];

		return null;
	}

	/**
	 * tell a given pool playing lameass to get moving and do his job
	 * @param lameass idle doctor
	 */
	private void kick (Doctor lameass)
	{
		if (lameass != null)
			lameass.endPoolGame();
		//else
		//WTF? no one playing pool? something must be broken! ;o)
	}
}
