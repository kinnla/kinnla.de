
package Alp3U3;

/**
 * ALP3 Uebung3
 * Marian Schwarz, Valentin Weckerle
 *
 * Interface PQueue which hides the implementation of the Priority Queue
 * from the Programmer of using classes.
 */
 public interface PQueue
{
	// Call this to get the smallest Object and remove it from Queue
	public Comparable removeMin ();

	// Call this to insert an object into the Queue
	public void insert (Comparable obj);

	// Returns Empty state of the Queue
	public boolean isEmpty ();

	// Returns the Size in Objects of the Queue
	public int size ();
}
