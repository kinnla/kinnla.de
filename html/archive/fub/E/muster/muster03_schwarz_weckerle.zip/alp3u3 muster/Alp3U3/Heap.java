
package Alp3U3;

import java.util.Vector;


/**
 * ALP3 Uebung3
 * Marian Schwarz, Valentin Weckerle
 *
 * Heap is the implemtentation of the PQueue interface and will hold all
 * Event related Objects in the simulation
 */
public class Heap implements PQueue
{
	private Vector tree = null;

	/**
	 * Constructor which initializes the storage vector and inserts a
	 * placeholder.
	 */
	public Heap ()
	{
		tree = new Vector();
		tree.add("placeholder"); //:P
	}

	/**
	 * removeMin is the public interface function which returns the first element
	 * of the stored dataset and restores the order of the remaining elements afterwards
	 *
	 * @return the removed object / null if heap is empty
	 */
	public Comparable removeMin ()
	{
		if (isEmpty())
			return null;

		//the smallest element of our dataset is the first entry in our storage vector
		//return this element and replace it with the last entry of the storage vector
		Object tmp = tree.get(1);
		tree.set(1,tree.lastElement());
		//now remove the last element (we just "moved" it to the first place in our storage vector)
		tree.remove(tree.size()-1);

		//restore the internal heap order if needed
		checkTooBig(1);

		return (Comparable)tmp;
	}

	/**
	 * insert is the public interface function which inserts a new element
	 * into the heap and triggers the reordering of the heap afterwards
	 * to ensure the heap order is restored
	 *
	 * @param obj object to insert into the heap
	 */
	public void insert (Comparable obj)
	{
		tree.add(obj);

		//retore the internal order
		checkTooSmall(tree.size()-1);
	}

	/**
	 * checks if the heap is empty
	 * this function is aware of our placeholder
	 *
	 * @return true if heap is empty, false otherwise
	 */
	public boolean isEmpty ()
	{
		return (tree.size() == 1);
	}

	/**
	 * returns the size of the heap
	 * the placeholder is taken into account
	 *
	 * @return number of objects on the heap
	 */
	public int size ()
	{
		return (tree.size()-1);
	}

	/**
	 * private function which implements the recursive algorithm to restore
	 * and maintain the internal order of the heap.
	 *
	 * checkTooSmall traverses the heap from the bottom to the top
	 *
	 * @param pos position (in storage vector) at which to start reordering
	 */
	private void checkTooSmall (int pos)
	{
		//we end the recursion once we reach the top of the heap
		if (pos == 1)
			return; //all done (root)

		//our parent is located at floor(pos/2)
		int parentpos = pos / 2;

		//abort if our parent is smaller than we are
		//our current element should be the only element which might violate the
		//heap order, so in this case we know that the heap order is restored
		if (((Comparable)tree.get(parentpos)).compareTo( tree.get(pos) ) <= 0)
			return; //element order is correct

		//switch positions with our parent
		switchElements(pos, parentpos);

		//continue to traverse the heap from the position of our current
		//parent element
		checkTooSmall(parentpos);
	}

	/**
	 * private function which implements the recursive algorithm to restore
	 * and maintain the internal order of the heap.
	 *
	 * checkTooBig traverses the heap from the top to the bottom
	 *
	 * @param pos position (in storage vector) at which to start reordering
	 */
	private void checkTooBig (int pos)
	{
		//our first child is located at our current position * 2
		int pos1 = 2*pos;
		//and our second child one position after that
		int pos2 = 2*pos + 1;

		int comparepos;

		//check if we have children, if not return
		//if we have only one child set the comparepos accordingly
		//we will use comparepos later to decide at which child we should look
		if ( invalidPos(pos1) || invalidPos(pos2) ) //only one child
		{
			if ( ! invalidPos(pos1) ) //we only have a left child
				comparepos = pos1;
			else if ( ! invalidPos(pos2) ) //we only have a right child
				comparepos = pos2;
			else //no children at all -> end recursion
				return;
		}

		//Both children exist but we're only interessted in the smaller one
		//so set comparepos accordingly
		else if (((Comparable)tree.get(pos1)).compareTo( tree.get(pos2) ) <= 0) //left child is smaller
			comparepos = pos1;
		else //right child is smaller
			comparepos = pos2;

		//end recursion if we're smaller than our smallest child
		if (((Comparable)tree.get(pos)).compareTo( tree.get(comparepos) ) <= 0) //[pos] <= [comparepos]
			return; //end recursion

		//switch places with our smallest child
		switchElements(pos, comparepos);

		//continue to traverse the heap from the position of our current
		//smallest child element
		checkTooBig(comparepos);
	}

	/**
	 * Internal function to enhance the readability of our code.
	 * The function switches elements of 2 given positions in the heap.
	 *
	 * @param pos1 Position 1
	 * @param pos2 Position 2
	 */
	private void switchElements (int pos1, int pos2)
	{
		Object tmp = tree.get(pos1);
		tree.set(pos1, tree.get(pos2));
		tree.set(pos2, tmp);
	}

	/**
	 * private function to improve readability in if clauses which
	 * would be bloated otherwise
	 * The function checks if the given position is still within the range of our storage vector
	 *
	 * @param pos Position to check
	 * @return true if inside vector range / false otherwise
	 */
	private boolean invalidPos(int pos)
	{
		return (pos >= tree.size());
	}
}
