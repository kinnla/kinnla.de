
package Alp3U3.Events;

import Alp3U3.Events.Event;
import Alp3U3.Patient;
import Alp3U3.Simulation;


/**
 * ALP3 Uebung3
 * Marian Schwarz, Valentin Weckerle
 *
 * EventNewPatient represents that a new victim has come to our pleasure dome
 * it's somewhat special since it directly spaws new event's of the same class
 * is that way we simulate that endless stream of victims coming.
 */
public class EventNewPatient extends Event
{
	private Patient p = null;

	/**
	 * Constructor which sets the triggertime ans instances a new patient object
	 * which holds all patient specific information
	 * @param time time when patient will enter the simulation
	 */
	public EventNewPatient (int time)
	{
		super(time);
		p = new Patient(time);
	}

	/**
	 * fire method which is called by the simulation which sends the patient
	 * to the reception and ensures that a new EventNewPatient is spawned and
	 * enqueued.
	 */
	public void fire ()
	{
		//enqueue this patient
		Simulation.receptionDesk.newPatient(p);

		//calculate time when the next patient comes
		int newTime = (int)(-1 * Simulation.lambda * Math.log( Math.random()));

		//create new patient event for next patient if still within office hours
		if (withinOfficeHours(newTime + Simulation.curtime))
		{
			//spawn an Event ..
			Simulation.events.insert(new EventNewPatient(Simulation.curtime + newTime));
		}
	}

	/**
	 * withinOfficeHours is simply the test if the simulation ends and no
	 * new patients should enter the queues
	 * @return true if still in simulating time / false if not
	 */
	private boolean withinOfficeHours (int time)
	{
		return (time < Simulation.length);
	}
}
