
package Alp3U3.Events;

import Alp3U3.Patient;
import Alp3U3.Simulation;


/**
 * ALP3 Uebung3
 * Marian Schwarz, Valentin Weckerle
 *
 * EventEndXray represents the Event that the xray procedure of a patient has ended
 */
public class EventEndXRay extends Event
{
	private Patient p = null;


	/**
	 * Constructor which just sets the corresponding attributes
	 * @param time time when this event will trigger
	 * @param p patient which survived xray procedure
	 */
	public EventEndXRay (int time, Patient p)
	{
		super(time);
		this.p = p;
	}

	/**
	 * Fire method of EventEndXray which is called from simulation
	 */
	public void fire ()
	{
		// log action
		Simulation.log("XRay treatment of patient "+p+" was finished. "+Simulation.formatTime(Simulation.curtime - p.getInTreatmentSince()));
		// Free the xray treatment room for the next patients
		Simulation.xray.currentPatientLeft();

		//patient needs to return to his owner or to the public queue, depending on simulation mode
		p.returnToQueue();

		//xray needs to check for new patients
		Simulation.xray.radiateNextPatient();
	}
}
