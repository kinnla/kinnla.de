
package Alp3U3.Events;

/**
 * ALP3 Uebung3
 * Marian Schwarz, Valentin Weckerle
 *
 * Abstract Class Event which represents the similarity's
 * between the Events used in the simulation. It also implements enough info to
 * ensure the interface comparable
 */
public abstract class Event implements Comparable
{
	protected int time;

	/**
	 * Constructor
	 * @param time time in seconds in which this event will happen
	 */
	public Event (int time)
	{
		this.time = time;
	}

	/**
	 * Abstract method which will implement behaviour if Event is triggered
	 */
	public abstract void fire ();


	/**
	 * compareTo ensures the interface comparable which allows us to easyly compare
	 * 2 events
	 * @param other Object to compare with
	 * @return 1 if we are "greater" 0 if we're equal -1 if other is "greater"
	 */
	public int compareTo (Object other)
	{
		if (time > ((Event)other).getTime())
			return 1;
		else if (time < ((Event)other).getTime())
			return -1;
		else
			return 0;
	}

	/**
	 * getTime enables reading of triggertime
	 * @return time when this event will trigger
	 */
	public int getTime ()
	{
		return time;
	}
}
