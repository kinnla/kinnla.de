import java.util.*;


public class CSimulation
{
	//Konstanten
	public final int CONSOLE_WIDTH = 100;
	public final int NUMBER_OF_DOCTORS = 5;
	public final int NUMBER_OF_XRAY_STATIONS = 2;
	public final int PROBABILITY_NEW_PATIENT_ARRIVES = 10;

	public final int STATISTICS_INTERVAL = 3600; //Statistik alle x Sekunden zeigen
	public final float PROBABILITY_OF_PATIENT_BEING_RELEASED = 0.15f;
	public final CTime WORK_SHIFT_START = new CTime(7 * 3600);
	public final CTime WORK_SHIFT_END = new CTime(11 * 3600);

	public final int LENGTH_PATIENT_QUEUE = 1000;

	public boolean FULLTRACE = true;
	public boolean noOutput = false;
	public int numberOfSimulations;
	public int usedPolicy; //0=XRay preferred; 1=all patients are equal
	public boolean usePriviligedQueue;

	public CTime worldTime;

	//�rzte
	public CDoctor[] doctors;
	public CXRayMedic[] xRayMedics; //Die tun die XRay Station bedienen

	//Queue f�r die Ereignisse
	public Halde eventQueue;
	public Vector allPatients;

	//Warteschlangen
	//Patientenwarteschlangen
	public CPatientQueue patientQueue;
	public CPatientPriviligedQueue patientPriviligedQueue;
    //XRAY Warteschlange
	public CXRayQueue xRayQueue;

	//Statistiken
	private int stat_numberOfPatients;
	private CTime stat_overallWaitingTime = new CTime();
	private CTime stat_averageWaitingTime= new CTime();
	private CTime stat_maximumWaitingTime= new CTime();
	
	private CTime stat_averageDoctorWaitingTime= new CTime();
	private CTime stat_averageClosingTime= new CTime();




	
    


	public boolean isRunning = false;

	public CSimulation(int policy, int numberOfSimulations, boolean noOutput)
	{		
		if(policy <0 || policy>1)throw new IllegalArgumentException("Unkown Policy");

		this.usedPolicy = policy;

		this.numberOfSimulations = numberOfSimulations;
		this.noOutput = noOutput;
		if(this.noOutput)FULLTRACE=false;

		eventQueue = new Halde(LENGTH_PATIENT_QUEUE);
		allPatients= new Vector(100);




		switch (this.usedPolicy)
		{
			case 0:
				usePriviligedQueue = true;
				patientPriviligedQueue = new CPatientPriviligedQueue(FULLTRACE);

				this.writeStat(Util.dottedLine(CONSOLE_WIDTH));
				this.writeStat(Util.centerStringBorder("Benutze priviligierte Schlange",CONSOLE_WIDTH));
				this.writeStat(Util.dottedLine(CONSOLE_WIDTH));
				break;
			case 1:
				this.writeStat(Util.dottedLine(CONSOLE_WIDTH));
				this.writeStat(Util.centerStringBorder("Keine priviligierte Schlange",CONSOLE_WIDTH));
				this.writeStat(Util.dottedLine(CONSOLE_WIDTH));
				break;
		}

		

	}

	public void Start() throws java.io.IOException
	{			
		this.writeStat(Util.dottedLine(CONSOLE_WIDTH));
		this.writeStat(Util.centerStringBorder("Simulationsstart mit " + this.numberOfSimulations + " Simulation(en)", CONSOLE_WIDTH));
		this.writeStat(Util.centerStringBorder("Anzahl der Aerzte: " + this.NUMBER_OF_DOCTORS, CONSOLE_WIDTH));
		this.writeStat(Util.centerStringBorder("Anzahl der Roentgenstationen: " + this.NUMBER_OF_XRAY_STATIONS, CONSOLE_WIDTH));
		this.writeStat(Util.centerStringBorder("W.keit das ein neuer Patient ankommt: " + this.PROBABILITY_NEW_PATIENT_ARRIVES, CONSOLE_WIDTH));
		this.writeStat(Util.centerStringBorder("W.keit das Patient nicht geroengt wird: " + this.PROBABILITY_OF_PATIENT_BEING_RELEASED, CONSOLE_WIDTH));
		this.writeStat(Util.centerStringBorder("Arbeitsbeginn: " + this.WORK_SHIFT_START.toString(), CONSOLE_WIDTH));
		this.writeStat(Util.centerStringBorder("Arbeitsende: " + this.WORK_SHIFT_END.toString(), CONSOLE_WIDTH));

		if(this.FULLTRACE)this.writeStat(Util.centerStringBorder("Erweiterte Ausgabe", CONSOLE_WIDTH));
		
		this.writeStat(Util.dottedLine(CONSOLE_WIDTH));


		for(int y=0; y < numberOfSimulations; y++)
		{
			//this.writeStat(Util.centerStringBorder("Tag " + y, CONSOLE_WIDTH));
			allPatients.removeAllElements();

			//�rzte initialisieren
			doctors = new CDoctor[NUMBER_OF_DOCTORS];
			for(int x = 0; x < NUMBER_OF_DOCTORS; x++)
			{
				doctors[x] = new CDoctor(Util.nameGen());
			}

			//XRay Stationen initialisieren
			xRayMedics = new CXRayMedic[NUMBER_OF_XRAY_STATIONS];
			for(int x = 0; x < NUMBER_OF_XRAY_STATIONS; x++)
			{
				xRayMedics[x] = new CXRayMedic(Util.nameGen());
			}

			//Warteschlangen initialisieren
			patientQueue = new CPatientQueue(FULLTRACE);
			xRayQueue = new CXRayQueue(FULLTRACE);

			CTime sTime = new CTime(WORK_SHIFT_START.getTicks());
			while (sTime.getHours() < 24)
			{
				eventQueue.einf�gen(new CEvent_printStatistics(this, new CTime(sTime.getTicks())));
				sTime.addSecond(STATISTICS_INTERVAL);
			}



			//Patientenank�nfte in die Ereignisqueue
			CTime pTime = new CTime(WORK_SHIFT_START.getTicks());				
			while(pTime.getHours() < 11)
			{			
				CPatient p=  new CPatient(Util.nameGen());
				pTime.addSecond((long)(60*(-PROBABILITY_NEW_PATIENT_ARRIVES)*Math.log(Math.random())));
				if(pTime.getHours() < 11)
				{
					eventQueue.einf�gen(new CEvent_NewPatientArrives(this, new CTime(pTime.getTicks()),p));
					allPatients.addElement(p);
				}
				else break;
			}

			this.MainLoop();
		}//Ende for(int y=0; y < numberOfSimulations; y++)

		//Statistiken

		this.writeStat(Util.dottedLine(CONSOLE_WIDTH));
		this.writeStat(Util.centerStringBorder("Statistik" ,CONSOLE_WIDTH));
		this.writeStat(Util.dottedLine(CONSOLE_WIDTH));
		this.writeStat(Util.centerStringBorder("Behandelte Patienten: "+ this.stat_numberOfPatients ,CONSOLE_WIDTH));
		this.writeStat(Util.centerStringBorder("Patienten pro Tag: "+ ((float) this.stat_numberOfPatients / (float) this.numberOfSimulations) ,CONSOLE_WIDTH));
		
		this.writeStat(Util.centerStringBorder("Gesamtwartezeit aller Patienten: " + this.stat_overallWaitingTime.toString(true),CONSOLE_WIDTH));
		this.writeStat(Util.centerStringBorder("Laengste Wartezeit eines Patienten: " + this.stat_maximumWaitingTime.toString(true),CONSOLE_WIDTH));
		
		this.writeStat(Util.centerStringBorder("Durchschnittliche Wartezeit: " + new CTime(this.stat_averageWaitingTime.getTicks() / this.numberOfSimulations).toString(true),CONSOLE_WIDTH));

		this.writeStat(Util.centerStringBorder("Durchschnittliche Wartezeit eines Arztes: " + new CTime(this.stat_averageDoctorWaitingTime.getTicks() / this.numberOfSimulations / this.NUMBER_OF_DOCTORS).toString(true),CONSOLE_WIDTH));

		this.writeStat(Util.centerStringBorder("Effektiver Ladenschluss: " + new CTime(this.stat_averageClosingTime.getTicks() / this.numberOfSimulations).toString(true),CONSOLE_WIDTH));
		
		this.writeStat(Util.dottedLine(CONSOLE_WIDTH));
		
		

	}

	public void MainLoop()throws java.io.IOException
	{
		isRunning=true;
		while(isRunning)
		{

			CEvent e = (CEvent) eventQueue.entferneMin();
			if(e!=null)
			{
				worldTime = e.time;
				e.doEvent();
				
			}
			else isRunning=false;
			
			//Warteschlangen
			//Privileged Warteschlange
			if(usePriviligedQueue)
			{
				if(!patientPriviligedQueue.isEmpty())
				{
					//gucken ob ein Arzt frei ist
					for(int x = 0; x < NUMBER_OF_DOCTORS; x++)
					{
						if(!doctors[x].isBusy)
						{//Patient zur Behandlung
							//Nur zum gleichen Arzt
							//Wenn der behandeldende Arzt frei ist wird er hier belegt
							//Es kann nicht passieren das er frei wird und aus einer anderen Schlange belegt wird.
							if(patientPriviligedQueue.getFirst().doctor == doctors[x])
							{
								eventQueue.einf�gen(new CEvent_PatientToDoctor(this, new CTime(e.time.getTicks()),
									patientPriviligedQueue.removeFirst(),
									doctors[x]));
								doctors[x].isBusy = true;
							}
							if(patientPriviligedQueue.isEmpty())break;
						}
					}
				}//Ende if(!patientPriviligedQueue.isEmpty())

			}
			//Wartet jemand in der Schlange?
			while(!patientQueue.isEmpty())
			{
				//Liste freier �rzte erstellen
				Vector freeDoctors = new Vector();

				//gucken welche �rzte frei sind
				for(int x = 0; x < NUMBER_OF_DOCTORS; x++)
				{					
					if(!doctors[x].isBusy)
					{
						freeDoctors.addElement(doctors[x]);                        
					}
				}
				if(freeDoctors.size() > 0)
				{//Zuf�llig den behandelnden Arzt ausw�hlen
					int r = Math.round((freeDoctors.size()-1) * (float)Math.random());
					//if(r > freeDoctors.size())r--;
					eventQueue.einf�gen(new CEvent_PatientToDoctor(this, new CTime(e.time.getTicks()),patientQueue.removeFirst(),(CDoctor) freeDoctors.elementAt(r)));
					((CDoctor) freeDoctors.elementAt(r)).isBusy = true;
					
				}
				else break;
			}//while(!patientQueue.isEmpty())

			//R�ntgenwarteschlange
			if(!xRayQueue.isEmpty())
			{
				//gucken ob eine Station frei ist
				for(int x = 0; x < NUMBER_OF_XRAY_STATIONS; x++)
				{
					if(!xRayMedics[x].isBusy)
					{//Patient zur Behandlung
						eventQueue.einf�gen(new CEvent_PatientToXRay(this, new CTime(e.time.getTicks()),xRayQueue.removeFirst(),xRayMedics[x]));
						xRayMedics[x].isBusy = true;
						if(xRayQueue.isEmpty())break;
					}
				}

			}

			//System.in.read();

		}//Ende while(isRunning)

		calcStatistic();
		if(!this.noOutput)this.printStatistic();

	}//Ende MainLoop

	public int getActivePatients()
	{
		int numberOfActivePatients=0;
		for(int x = 0; x < allPatients.size(); x++)
		{
			if(((CPatient)allPatients.elementAt(x)).isActive) ++numberOfActivePatients;
		}
		return numberOfActivePatients;
	}

	//Funktionen zu statistischen Auswertung
	public void calcStatistic()
	{
        this.stat_numberOfPatients += allPatients.size();
		if(longestWaitingTime().compareTo(this.stat_maximumWaitingTime)>0)this.stat_maximumWaitingTime = longestWaitingTime();
		if(allPatients.size()!=0)
            this.stat_averageWaitingTime.addSecond(accumulatedQueueTime().getTicks() / allPatients.size());
		this.stat_overallWaitingTime.addSecond(accumulatedQueueTime().getTicks());
		this.stat_averageClosingTime.addSecond(timeLastPatientLeft().getTicks());
		this.stat_averageDoctorWaitingTime.addSecond(accumulatedDoctorIdleTime().getTicks());

	}
	public void printStatistic()
	{
		this.write(Util.dottedLine(CONSOLE_WIDTH));
		this.write(Util.centerStringBorder("Statistik" ,CONSOLE_WIDTH));
		this.write(Util.dottedLine(CONSOLE_WIDTH));
		this.write(Util.centerStringBorder("Tag endete um: " + timeLastPatientLeft().toString() ,CONSOLE_WIDTH));
		this.write(Util.centerStringBorder("Behandelte Patienten: " + allPatients.size(),CONSOLE_WIDTH));
		this.write(Util.centerStringBorder("Gesamtwartezeit aller Patienten: " + accumulatedQueueTime().toString(true) ,CONSOLE_WIDTH));
		this.write(Util.centerStringBorder("Laengste Wartezeit eines Patienten: " + longestWaitingTime().toString(true) ,CONSOLE_WIDTH));
		
		CTime averageWait = new CTime(accumulatedQueueTime().getTicks() / allPatients.size());
		this.write(Util.centerStringBorder("Durchschnittliche Wartezeit: " + averageWait.toString(true) ,CONSOLE_WIDTH));

		for(int x = 0; x < NUMBER_OF_DOCTORS; x++)
		{
			this.write(Util.centerStringBorder(doctors[x].name+ " wartete " + doctors[x].timeWaiting.toString(true) ,CONSOLE_WIDTH));
		}


		CTime adTime = new CTime(accumulatedDoctorIdleTime().getTicks() / doctors.length);
		this.write(Util.centerStringBorder("Die Aerzte warteten durchschnittlich: " + adTime.toString(true) ,CONSOLE_WIDTH));




		
		this.write(Util.dottedLine(CONSOLE_WIDTH));	


		if(FULLTRACE)
		{
			for(int x = 0; x < allPatients.size(); x++)
			{

				this.write(Util.centerStringBorder(((CPatient)allPatients.elementAt(x)).name,CONSOLE_WIDTH));
				this.write(Util.centerStringBorder("Ankunftszeit: " + ((CPatient)allPatients.elementAt(x)).timeEnterER.toString(true),CONSOLE_WIDTH));
				this.write(Util.centerStringBorder("Gesamtwartezeit: " + ((CPatient)allPatients.elementAt(x)).timeWaitingInQueue.toString(true),CONSOLE_WIDTH));
				this.write(Util.centerStringBorder("Wartezeit vorm Doktor: " + ((CPatient)allPatients.elementAt(x)).timeWaitingInDoctorQueue.toString(true),CONSOLE_WIDTH));
				this.write(Util.centerStringBorder("Wartezeit in priviligierter Schlange: " + ((CPatient)allPatients.elementAt(x)).timeWaitingInPrivQueue.toString(true),CONSOLE_WIDTH));
				this.write(Util.centerStringBorder("----" ,CONSOLE_WIDTH));	
			}
		}



	}

	//Gibt die Zeit zur�ck an der der letzte Patient entlassen wurde
	private CTime timeLastPatientLeft()
	{
		CTime t = new CTime();
		for(int x = 0; x < allPatients.size(); x++)
		{
			if(((CPatient)allPatients.elementAt(x)).timeLeftER.getTicks() > t.getTicks())
			{
				t = ((CPatient)allPatients.elementAt(x)).timeLeftER;
			}
		}
		return t;
	}

	private CTime longestWaitingTime()
	{
		CTime t = new CTime();
		for(int x = 0; x < allPatients.size(); x++)
		{
			if(((CPatient)allPatients.elementAt(x)).timeWaitingInDoctorQueue.getTicks() > t.getTicks())
			{
				t = ((CPatient)allPatients.elementAt(x)).timeWaitingInDoctorQueue;
			}
			if(((CPatient)allPatients.elementAt(x)).timeWaitingInPrivQueue.getTicks() > t.getTicks())
			{
				t = ((CPatient)allPatients.elementAt(x)).timeWaitingInPrivQueue;
			}
			if(((CPatient)allPatients.elementAt(x)).timeWaitingInXRayQueue.getTicks() > t.getTicks())
			{
				t = ((CPatient)allPatients.elementAt(x)).timeWaitingInXRayQueue;
			}
		}
		return t;
	}

	private CTime accumulatedQueueTime()
	{
		CTime t = new CTime();
		for(int x = 0; x < allPatients.size(); x++)
		{
			t.setTicks(((CPatient)allPatients.elementAt(x)).timeWaitingInQueue.getTicks() + t.getTicks());
		}
		return t;
	}

	private CTime accumulatedDoctorIdleTime()
	{
		CTime t = new CTime();
		for(int x = 0; x < doctors.length; x++)
		{
			t.setTicks(doctors[x].timeWaiting.getTicks() + t.getTicks());
		}
		return t;
	}

	public void write(String msg)
	{
		if(!this.noOutput)System.out.println(msg);
	}
	public void writeStat(String msg)
	{
		System.out.println(msg);
	}


}
