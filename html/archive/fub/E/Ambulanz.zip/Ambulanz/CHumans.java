

/**
 * Zusammenfassung f�r CHumans.
 */
abstract class CHumans
{
	public String name;
	

	public boolean isActive = false;


	public CHumans(String name)
	{
		//
		// TODO: Konstruktorlogik hier hinzuf�gen
		//
		this.name = name;
	}
}

class CPatient extends CHumans
{
	
	public boolean hasBeenXrayed = false;

	public CTime timeWaitingInQueue; //Gesamtzeit die wartend verbracht wird
	public CTime timeWaitingInDoctorQueue; //Wartezeit vot dem �ztezimmer
	public CTime timeWaitingInXRayQueue;
	public CTime timeWaitingInPrivQueue;
	public CTime timeExamination1; //Zeit f�r die erste Untersuchung
	public CTime timeExamination2; //Zeit f�r die 2. Untersuchung
	public CTime timeXRAY; //Dauer des XRays
	public CTime timeLeftER; //Zeitpunkt an dem der Patient entlassen wurde
	public CTime timeEnterER; 

	public CTime queueStart; //Um das Eintreten in eine Warteschlange zu speichern


	public CDoctor doctor; //betreunder Arzt

	public  CPatient(String name)
	{
		super(name);

		timeWaitingInQueue = new CTime();
		timeWaitingInDoctorQueue = new CTime();
		timeWaitingInXRayQueue = new CTime();
		timeWaitingInPrivQueue = new CTime();
		timeExamination1 = new CTime();
		timeExamination2 = new CTime();
		timeXRAY = new CTime();
		timeLeftER = new CTime();
		timeEnterER = new CTime();
		queueStart = new CTime();
	}
}

class CDoctor extends CHumans
{
	public boolean isBusy;

	public CTime startWait;
	public CTime timeWaiting;

	public  CDoctor(String name)
	{
		super("Dr. " + name);
		isBusy = false;
		startWait = new CTime();
		timeWaiting = new CTime();
	}
}

class CXRayMedic extends CHumans
{
	public boolean isBusy;

	public  CXRayMedic(String name)
	{
		super("Assistent " + name);
		isBusy = false;
	}
}
