

public class Halde implements PWSchlange
{
	// aktuelle L�nge
	protected int length;

	// unterliegendes Array
	protected Comparable [] heap;

	public Halde(int length)
	{
		this.length = 0;
		heap = new Comparable[length];
	}

	public void einf�gen(Comparable x) throws RuntimeException
	{
		if(length >= heap.length)
			throw new RuntimeException("Heap voll");

		heap[++length] = x;
		zuklein(length);
	}

	public Comparable entferneMin() //throws java.util.NoSuchElementException
	{
		if(length<=0)
			return null;

		Comparable x = heap[1];
		length--;

		if(length>0)
		{
			heap[1] = heap[length+1];
			zugro�(1);
		}

		return x;
	}

	protected void zuklein(int i)
	{
		if(i==1)
			return;

		int vorg�ngerIndex = i / 2;
		if(heap[i].compareTo(heap[vorg�ngerIndex]) < 0)
		{
			vertausche(i, vorg�ngerIndex);
			zuklein(vorg�ngerIndex);
		}
	}

	protected void zugro�(int i)
	{
		int kleinsterNachfolger;
		if (2*i+1 <= length) 
		{
			if (heap[2*i].compareTo(heap[2*i+1]) < 0)
				kleinsterNachfolger = 2*i;
			else
				kleinsterNachfolger = 2*i+1;
		}

		else if (2*i <= length)
			kleinsterNachfolger = 2*i;
		else
			return;

		if (heap[i].compareTo(heap[kleinsterNachfolger]) > 0) 
		{
			vertausche(i, kleinsterNachfolger);
			zugro�(kleinsterNachfolger);
		}
	}

	protected void vertausche(int i, int j)
	{
		Comparable x = heap[i];
		heap[i] = heap[j];
		heap[j] = x;
	}
}