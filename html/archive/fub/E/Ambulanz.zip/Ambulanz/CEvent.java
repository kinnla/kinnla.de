

/**
 * Zusammenfassung f�r CEvent.
 * Basisklasse aller Events
 */
abstract class CEvent implements Comparable
{
	CTime time;
	CSimulation simulation;
	String name;

	public CEvent(CSimulation simulation, CTime time)
	{
		//
		// TODO: Konstruktorlogik hier hinzuf�gen
		//
		this.time = time;
		//Instanz der aufrufenden, �bergeordneten Klasse.
		//Das ist nat�rlich extremstes Antiinformationhiding,
		//aber die Aufgabe ist komplex genug und die Zeit knapp.
		this.simulation = simulation;
	}

	public abstract void doEvent();

	
	public int compareTo(Object arg0)
	{
		return time.compareTo(((CEvent)arg0).time);
	}
}

class CEvent_NewPatientArrives extends CEvent
{
	CPatient patient; //Zeiger auf den Patienten
	CEvent_NewPatientArrives(CSimulation simulation, CTime time,CPatient patient)
	{
		//�bergeordneten Konstruktor aufrufen
		super(simulation, time);
        this.name = "NewPatientArrives"; 
		this.patient = patient;
	}

	

	public void doEvent()
	{
		//Keine neuen Patienten nach Betriebsschluss zulassen
		if(this.time.compareTo(simulation.WORK_SHIFT_END)>0)return;

		//Patienten aktivieren
		patient.isActive = true;

		//Ausgabe
		simulation.write(this.time.toString() + ": " + patient.name + " betritt die Ambulanz.");

		//In die Warteschlange vorm Arztzimmer		
		simulation.patientQueue.addPatient(patient);
		//Zeitpunkt des Eintritts merken
		patient.timeEnterER.setTicks(time.getTicks());
		patient.queueStart.setTicks(time.getTicks());
	}
}

class CEvent_PatientToDoctor extends CEvent
{
	CPatient patient;
	CDoctor doctor; 

	CEvent_PatientToDoctor(CSimulation simulation, CTime time,CPatient patient,CDoctor doctor)
	{
		//�bergeordneten Konstruktor aufrufen
		super(simulation, time);
		this.name = "PatientToDoctor"; 
		this.patient = patient;
		this.doctor = doctor;
	}

	public void doEvent()
	{
		doctor.isBusy = true;
		//Ausgabe
		simulation.write(this.time.toString() + ": " + patient.name + " wird von " + doctor.name + " behandelt.");

		//Zeit die der Doktor auf Patient wartete merken
		if(doctor.startWait.getTicks() == 0)doctor.startWait.setTicks(simulation.WORK_SHIFT_START.getTicks());
		doctor.timeWaiting.setTicks(time.getTicks() - doctor.startWait.getTicks() + doctor.timeWaiting.getTicks());

		//Zeit vermerken die der Patient warten musste
		//Beachten in welcher Schlange sich der Paient befand
		if(patient.hasBeenXrayed && simulation.usePriviligedQueue)
		{//Patient war in der bevorzugten Schlange
			patient.timeWaitingInPrivQueue.setTicks(time.getTicks() - patient.queueStart.getTicks());
			patient.timeWaitingInQueue.setTicks(patient.timeWaitingInPrivQueue.getTicks() + patient.timeWaitingInQueue.getTicks());
		}
		else
		{
			patient.timeWaitingInDoctorQueue.setTicks(time.getTicks() - patient.queueStart.getTicks());
			patient.timeWaitingInQueue.setTicks(patient.timeWaitingInDoctorQueue.getTicks() + patient.timeWaitingInQueue.getTicks());
		}
		


		//Event das Doktor fertig ist
		CTime t;
		if(patient.hasBeenXrayed)
		{//Die 2. Behandlung dauert l�nger
			t = new CTime((long)((10+(30-10)*Math.random())*60) + simulation.worldTime.getTicks());			
			patient.timeExamination2.setTicks(t.getTicks() - simulation.worldTime.getTicks());
		}
		else
		{
			t = new CTime((long)((5+(20-5)*Math.random())*60) + simulation.worldTime.getTicks());
			patient.timeExamination1.setTicks(t.getTicks() - simulation.worldTime.getTicks());
		}
		simulation.eventQueue.einf�gen(new CEvent_DoctorFinishedExamination(simulation,	t, patient, doctor));
                
	}
}

class CEvent_DoctorFinishedExamination extends CEvent
{
	CPatient patient;
	CDoctor doctor; 

	CEvent_DoctorFinishedExamination(CSimulation simulation, CTime time,CPatient patient,CDoctor doctor)
	{
		//�bergeordneten Konstruktor aufrufen
		super(simulation, time);
		this.name = "DoctorFinishedExamination"; 
		this.patient = patient;
		this.doctor = doctor;
	}

	public void doEvent()
	{
		doctor.isBusy = false;
		doctor.startWait.setTicks(time.getTicks());
		patient.doctor = this.doctor;

		//Zum R�ntgen?
		if((Math.random() >= (double) simulation.PROBABILITY_OF_PATIENT_BEING_RELEASED) && !patient.hasBeenXrayed)
		{//zum R�ntgen
			simulation.write(this.time.toString() + ": " + patient.name + " wird von " + doctor.name + " zum Roentgen geschickt.");
			//TODO: R�ntgen Event
            			
			simulation.eventQueue.einf�gen(new CEvent_ArrivesAtXRay(simulation,
				new CTime((simulation.worldTime.getTicks()))
				, patient));
			
		}
		else
		{//Patient wird entlassen
			simulation.write(this.time.toString() + ": " + patient.name + " wird von " + doctor.name + " aus der Ambulanz entlassen.");
			patient.isActive=false;
			patient.timeLeftER.setTicks(time.getTicks());
		}	
        
	}
}

class CEvent_ArrivesAtXRay extends CEvent
{
	CPatient patient;	

	CEvent_ArrivesAtXRay(CSimulation simulation, CTime time,CPatient patient)
	{
		//�bergeordneten Konstruktor aufrufen
		super(simulation, time);
		this.name = "PatientToXRay"; 
		this.patient = patient;
		
	}
	public void doEvent()
	{
		//Ausgabe
		simulation.write(this.time.toString() + ": " + patient.name + " kommt an der Roentgenstation an.");

		//Eintritt in die Warteschlange vermerken
		patient.queueStart.setTicks(time.getTicks());
		//In die Warteschlange vorm Arztzimmer
		simulation.xRayQueue.addPatient(patient);
	}    
}

class CEvent_PatientToXRay extends CEvent
{
	CPatient patient;
	CXRayMedic xray; 

	CEvent_PatientToXRay(CSimulation simulation, CTime time,CPatient patient,CXRayMedic xray)
	{
		//�bergeordneten Konstruktor aufrufen
		super(simulation, time);
		this.name = "PatientToXRay"; 
		this.patient = patient;
		this.xray = xray;
	}

	public void doEvent()
	{
		xray.isBusy = true;
		//Ausgabe
		simulation.write(this.time.toString() + ": " + patient.name + " wird von " + xray.name + " auf den Roentgentisch gelegt.");

		//Zeit vermerken die der Patient warten musste
		patient.timeWaitingInXRayQueue.setTicks(time.getTicks() - patient.queueStart.getTicks());
		patient.timeWaitingInQueue.setTicks(patient.timeWaitingInQueue.getTicks() + patient.timeWaitingInXRayQueue.getTicks());
		


		//Event das xray fertig ist
		CTime xTime = new CTime((long)((5+(10-5)*Math.random())*60) + simulation.worldTime.getTicks());
		simulation.eventQueue.einf�gen(new CEvent_XRayFinished(simulation, xTime, patient, xray));

		//Dauer des XRay merken
		patient.timeXRAY.setTicks(xTime.getTicks() - simulation.worldTime.getTicks());
                
	}
}

class CEvent_XRayFinished extends CEvent
{
	CPatient patient;
	CXRayMedic xray; 

	CEvent_XRayFinished(CSimulation simulation, CTime time,CPatient patient,CXRayMedic xray)
	{
		//�bergeordneten Konstruktor aufrufen
		super(simulation, time);
		this.name = "XRayFinished"; 
		this.patient = patient;
		this.xray = xray;
	}

	public void doEvent()
	{
		xray.isBusy = false;
		patient.hasBeenXrayed = true;
		//Ausgabe
		simulation.write(this.time.toString() + ": " + patient.name + " verlaesst die Roentgenstation.");

		if(simulation.usePriviligedQueue)
		{//Patienten die vom r�ntgen wiederkommen in die bevorzugte Schlange
			simulation.patientPriviligedQueue.addPatient(patient);
		}
		else
		{//Patienten m�ssen sich wieder in die Standardschlange einreihen
			simulation.patientQueue.addPatient(patient);
		}

		//Eintritt in die Queue merken
		patient.queueStart.setTicks(time.getTicks());
        
	}
}

class CEvent_printStatistics extends CEvent
{
	CEvent_printStatistics(CSimulation simulation, CTime time)
	{
		//�bergeordneten Konstruktor aufrufen
		super(simulation, time);
		this.name = "printStatistics";		
	}
	public void doEvent()
	{
		if(simulation.getActivePatients() < 1)return;
		simulation.write(Util.dottedLine(simulation.CONSOLE_WIDTH));
		simulation.write(Util.centerString(time.toString(),simulation.CONSOLE_WIDTH));
		simulation.write(Util.centerString("Anzahl Patienten: " + simulation.getActivePatients() + 
			"; Wartend auf Arzt " + (simulation.patientQueue.length()) +
			"; Wartend auf Roentgen: " + (simulation.xRayQueue.length()),simulation.CONSOLE_WIDTH));
		
		if(simulation.usePriviligedQueue)
			simulation.write(Util.centerString("Anzahl Patienten in der priviligierten Schlange: " + 
				(simulation.patientPriviligedQueue.length()),simulation.CONSOLE_WIDTH));

		simulation.write(Util.dottedLine(simulation.CONSOLE_WIDTH));        
	}
}
