


public class Main
{
	public Main()
	{
	}

	/** @attribute System.STAThread() */
	public static void main(String[] args) throws java.io.IOException
	{
		//
		// TODO: Code zum Starten der Anwendung hier hinzuf�gen
		//
		CSimulation simulation = new CSimulation(0,1,false);
		simulation.Start();

		System.in.read();
	}
}
