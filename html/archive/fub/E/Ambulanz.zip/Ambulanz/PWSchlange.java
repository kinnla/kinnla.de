

interface PWSchlange
{
	Comparable entferneMin();
	void einf�gen(Comparable x);
}