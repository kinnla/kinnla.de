

import java.util.*;
/**
 * Zusammenfassung f�r CQueue.
 */
public abstract class CQueue implements Comparable
{
	private LinkedList list;
	boolean fullTrace;
    
		 
	public CQueue(boolean fullTrace)
	{
		list = new LinkedList();
		this.fullTrace = fullTrace;
	}

	public int compareTo(Object arg0)
	{		
		if(this.list.size() < ((CQueue)arg0).list.size())return -1;
		if(this.list.size() < ((CQueue)arg0).list.size())return 0;
		return 1;
	}

	public void addPatient(CPatient p)
	{
		list.addLast(p);
	}

	public boolean isEmpty()
	{
		return list.isEmpty();
	}

	public CPatient removeFirst()
	{
		return (CPatient) list.removeFirst();
	}

	public CPatient getFirst()
	{
		return (CPatient) list.getFirst();
	}

	public int length()
	{
		return list.size();
	}

}

class CPatientQueue extends CQueue
{
	public CPatientQueue(boolean fullTrace)
	{
		super(fullTrace);
	}

	public void addPatient(CPatient p)
	{
		if(this.fullTrace)Util.write("     ->A: " + p.name + " tritt in die Aerztewarteschlange ein.");
		super.addPatient(p);
	}

	public CPatient removeFirst()
	{		
        CPatient p = super.removeFirst();
        if(this.fullTrace)Util.write("     <-A: " + p.name + " verlaesst die Aerztewarteschlange.");
		return p;
	}
}

class CXRayQueue extends CQueue
{
	public CXRayQueue(boolean fullTrace)
	{
		super(fullTrace);
	}
	public void addPatient(CPatient p)
	{
		if(this.fullTrace)Util.write("     ->R: " + p.name + " tritt in die Roentgenwarteschlange ein.");
		super.addPatient(p);
	}

	public CPatient removeFirst()
	{		
		CPatient p = super.removeFirst();
		if(this.fullTrace)Util.write("     <-R: " + p.name + " verlaesst die Roentgenwarteschlange.");
		return p;
	}
}

class CPatientPriviligedQueue extends CQueue
{
	public CPatientPriviligedQueue(boolean fullTrace)
	{
		super(fullTrace);
	}

	public void addPatient(CPatient p)
	{
		if(this.fullTrace)Util.write("     ->B: " + p.name + " tritt in die bevorzugte Aerztewarteschlange ein.");
		super.addPatient(p);
	}

	public CPatient removeFirst()
	{		
		CPatient p = super.removeFirst();
		if(this.fullTrace)Util.write("     <-B: " + p.name + " verlaesst die bevorzugte Aerztewarteschlange.");
		return p;
	}
}
