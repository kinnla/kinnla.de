

/**
 * Zusammenfassung f�r Util.
 * statische Utilityfunktionen die nicht in andere Klassen geh�ren
 */
public class Util
{
	public Util()
	{
		//
		// TODO: Konstruktorlogik hier hinzuf�gen
		//
	}

	public static void write(String msg)
	{
		System.out.println(msg);
	}

	public static String dottedLine(int m_Breite)
	{//Gibt eine *****... Linie aus
		String s = "";
		for (int x = 0; x < m_Breite; x++)
		{
			s += "*";
		}
		return s;
	}
	public static String centerStringBorder(String s, int m_Breite)
	{//Zentriert einen String und umrahmt in mit *
		int l = s.length();
		int padding =(m_Breite - l) / 2;
		String sPad = "";
		if (s.length() == 0)
		{
			for (int x = 0; x < m_Breite - 2; x++)
			{
				sPad += " ";
			}
			s = "*" + sPad + "*";
			return s;
		}
		for (int x = 0; x < padding - 1; x++)
		{
			sPad += " ";
		}
		if (l % 2 == 0)
		{
			s = "*" + sPad + s + sPad + "*";
		}
		else
		{
			s = "*" + sPad + s + sPad + " *";
		}
		return s;
	}
	public static String centerString(String s, int m_Breite)
	{//Zentriert einen String
		int l = s.length();
		int padding = (m_Breite - l) / 2;
		String sPad = "";
		for (int x = 0; x < padding; x++)
		{
			sPad += " ";
		}
		if (l % 2 == 0)
		{
			s = sPad + s + sPad;
		}
		else
		{
			s = sPad + s + sPad + " ";
		}
		return s;
	}



	public static String nameGen()
	{
		final String[] vornamen = new String[]{"Peter", "Paul", "Steffen", "Markus", "Torsten", "Sabine", "Paula", "Verana", "Anselm", "Irina", "Bianca", "Herbert", "Klaus", "Simone", "Jan", "Stefan", "Marco", "Dieter", "Ralf", "Rainer", "Rudolf", "Ruediger", "Tim", "Till", "Tom", "Alfred", "Heinz", "Heinrich", "Hannelore", "Manfred", "Werner", "Wilhelm", "Guenther", "Tanja", "Steffi", "Christina", "Detlef", "Karl-Heinz", "Gerhard", "Alexander", "Christian", "Gertrud", "Gudrun", "Frieda", "Vanessa", "Verona", "Veronika", "Natascha", "Leoni", "Marlene", "Melanie", "Mechthild","Axel", "Irmgard", "Joschka"};

		final String[] nachnamen = new String[]{"Fischer","Schuster","Schneider","Zimmermann","Mueller","Meier","Haase","Brueggemann","Knuefer","Richter","Baermann","Lange","Hildebrandt","Baum","Baumgaertner","Todtenhaupt","Pest","Kranach","Zoppke","Gleichmann","Binger","Kirfel","Mali","Schreier","Zoellner","Winter","Sommer","Herbst","Steinmetz","Werner","Brill","Papula","Schweiss", "Brohmer","Homa","Knippers","Tolkien","King","Munk","Ringelnatz","Goethe","Strassburger","Gottschalk","Hilgers","Rau","Gettgens","Huebsch","Merkel","Stoiber","Merz","Westerwelle","Klugscheiss","Kaiser"};

		//System.Random r = new System.Random();
		return vornamen[(int)(Math.random() * vornamen.length)] + " " + nachnamen[(int)(Math.random() * nachnamen.length)];

	}
}
