
package Alp3U8;

import java.util.Vector;
import java.util.Enumeration;


/**
 * ALP3 Uebung3
 * Marian Schwarz, Valentin Weckerle
 *
 * Patient Class
 */
public class Patient
{
	//time at which this patient entered the ambulance
	private int beginVisit = 0;
	//internal timer for waiting times
	private int waitingSince = -1;
	//internal counter which is incremented after each wait to reflect the
	//total number of seconds waited
	private int waitingTime = 0;
	private int inTreatmentSince = -1;
	private boolean wasXray = false;
	//name of this patient
	private int patId = 0;
	//personal doctor, if any
	private Doctor personalDoctor = null;
	//emergency flag
	private boolean emerg = false;

	//patient file which records the treatment history of this patient
	private Vector patientFile = null;
	//current radiation level
	private int radiationLevel = 0;

	/**
	 * create a new patient
	 * @param time current time
	 */
	public Patient (int time)
	{
		beginVisit = time;
		waitingTime = 0;
		patientFile = new Vector();
	}

	/**
	 * create a new patient
	 * @param time current time
	 * @param emerg true if emergency patient
	 */
	public Patient (int time, boolean emerg)
	{
		this.emerg = emerg;
		beginVisit = time;
		waitingTime = 0;
		patientFile = new Vector();
	}

	/**
	 * assign a patient Id to this patient
	 * @param patId patient id
	 */
	public void givePatientNumber (int patId)
	{
		//only use new patId if we don't have one already
		if (this.patId == 0)
		{
			this.patId = patId;
			log("patient id assigned: "+patId);
		}
	}

	/**
	 * assign a personal doctor to this patient, the patient will return
	 * to the private queue of this doctor after a xray treatment if the simulation
	 * runs in SIMULATION_DOCTYPE_PRIVATEDOC mode
	 * @param doc personal doctor
	 */
	public void assignDoctor (Doctor doc)
	{
		if (personalDoctor != null)
			return;

		personalDoctor = doc;
		log("doctor assigned: "+doc);
	}

	/**
	 * return to either the personal queue of the assigned doctor or the main queue
	 * of the reception, depending on the simulation mode
	 */
	public void returnToQueue ()
	{
		if (Simulation.doctype == Simulation.SIMULATION_DOCTYPE_PRIVATEDOC)
		{
			Simulation.log("Patient "+this+" is returning to Doctor "+personalDoctor+", "+personalDoctor.getWaitingRoomSize()+" other Patients are waiting.");
			log("returning to doctor: "+personalDoctor);
			personalDoctor.newPrivateVictim(this);
		}
		else if (Simulation.doctype == Simulation.SIMULATION_DOCTYPE_PUBLICDOC)
		{
			Simulation.log("Patient "+this+" is returning to the Reception, "+Simulation.receptionDesk.getWaitingRoomSize()+" other Patients are waiting.");
			log("returning to reception");
			Simulation.receptionDesk.newPatient(this);
		}
	}

	/**
	 * leave the ambulance and update stats
	 */
	public void leave ()
	{
		log("leaving after "+Simulation.formatTime(Simulation.curtime - beginVisit)+", begin: "+Simulation.formatTime(beginVisit));
		Simulation.statPatientLeft(this);
	}

	/**
	 * begin waiting
	 * @param queue name of current waiting queue (doc, xray)
	 */
	public void startWaiting (String queue)
	{
		log("waiting for "+queue);
		waitingSince = Simulation.curtime;
		inTreatmentSince = -1;
	}

	/**
	 * end waiting, updates waiting time counters
	 * @param queue name of current waiting queue (doc, xray)
	 */
	public void stopWaiting (String queue)
	{
		if (waitingSince == -1)
			return;
		log("finished waiting for "+queue);
		waitingTime += Simulation.curtime - waitingSince;
		waitingSince = -1;
		inTreatmentSince = Simulation.curtime;
	}

	/**
	 * called once a patient finished a xray treatment
	 * internal state is updated and radiationlevel is increased
	 */
	public void wasXray ()
	{
		wasXray = true;
		increaseRadiationLevel();
		log("xray examination, new radiationlevel: "+radiationLevel);
	}

	/**
	 * @return time of begin of visit
	 */
	public int getBeginVisit ()
	{
		return beginVisit;
	}

	/**
	 * @return true if this patient already was in at least one xray treatment
	 */
	public boolean getWasXray ()
	{
		return wasXray;
	}

	/**
	 * @return total time in seconds this patient waited so far
	 */
	public int getWaitingTime ()
	{
		return waitingTime;
	}

	/**
	 * @return this patient's id
	 */
	public int getPatId ()
	{
		return patId;
	}

	/**
	 * @return name of this patient
	 */
	public String toString ()
	{
		if (emerg)
			return "EP-"+patId;
		else
			return "P-"+patId;
	}

	/**
	 * @return radiation level of this patient
	 */
	public int getRadiationLevel ()
	{
		return radiationLevel;
	}

	/**
	 * add an entry to the personal patient file of this patient
	 * @param msg log message
	 */
	public void log (String msg)
	{
		patientFile.add("["+Simulation.formatTime(Simulation.curtime+7*60*60)+"] "+msg);
	}

	/**
	 * return "formated" patient file entries
	 * @return patient file
	 */
	public String getPatientFile ()
	{
		StringBuffer buf = new StringBuffer();
		Enumeration e = patientFile.elements();
		buf.append("Patient File for P-"+patId+":\n");
		while (e.hasMoreElements())
		{
			buf.append(">> ");
			buf.append((String)e.nextElement());
			buf.append("\n");
		}
		return buf.toString();
	}

	/**
	 * @return begin of treatment time for this patient
	 */
	public int getInTreatmentSince()
	{
		return inTreatmentSince;
	}

	/**
	 * @return whether this patient is an emergency patient or not 
	 */
	public boolean isEmerg()
	{
		return emerg;
	}

	/**
	 * increase the radiation level for this patient and print a log message if needed
	 */
	private void increaseRadiationLevel ()
	{
		radiationLevel++;

		if (radiationLevel == 5)
			Simulation.log("Patient "+this+" is not feeling well after his "+radiationLevel+". XRay treatment.");
		else if (radiationLevel == 8)
			Simulation.log("Patient "+this+" is feeling sick after his "+radiationLevel+". XRay treatment.");
		else if (radiationLevel == 10)
			Simulation.log("Patient "+this+" has a slight greenish glow to him after his "+radiationLevel+". XRay treatment.");
		else if (radiationLevel == 15)
			Simulation.log("Patient "+this+" can now read in the dark.");
		else if (radiationLevel == 20)
			Simulation.log("Patient "+this+" just noticed his brand new third hand.");
		else if (radiationLevel == 25)
			Simulation.log("Patient "+this+" can now see through walls.");
		else if (radiationLevel == 30)
			Simulation.log("Patient "+this+" is now his own electricity source.");
	}
}
