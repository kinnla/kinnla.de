
package Alp3U8.Events;

import Alp3U8.Patient;
import Alp3U8.Simulation;


/**
 * ALP3 Uebung8
 * Marian Schwarz, Valentin Weckerle
 *
 * EventNewEmergPatient is the new event for emergency patients, other than the different
 * lambda value used and the fact that we send new emergency patient to the reception via
 * newEmergPatient() it's basically a EventNewPatient event.
 */
public class EventNewEmergPatient extends Event
{
	private Patient p = null;

	/**
	 * Constructor which sets the triggertime and instances a new patient object
	 * which holds all patient specific information
	 * @param time time when patient will enter the simulation
	 */
	public EventNewEmergPatient (int time)
	{
		super(time);
		p = new Patient(time, true);
	}

	/**
	 * fire method which is called by the simulation which sends the patient
	 * to the reception and ensures that a new EventNewEmergPatient is spawned and
	 * enqueued.
	 */
	public void fire ()
	{
		//enqueue this patient
		Simulation.receptionDesk.newEmergPatient(p);

		//calculate time when the next patient comes
		int newTime = (int)(-1 * Simulation.lambda2 * Math.log( Math.random()));

		//create new patient event for next patient if still within office hours
		if (withinOfficeHours(newTime + Simulation.curtime))
		{
			//spawn an Event ..
			Simulation.events.insert(new EventNewEmergPatient(Simulation.curtime + newTime));
		}
	}


	/**
	 * withinOfficeHours is simply the test if the simulation ends and no
	 * new patients should enter the queues
	 * @return true if still in simulating time / false if not
	 */
	private boolean withinOfficeHours (int time)
	{
		return (time < Simulation.length);
	}
}
