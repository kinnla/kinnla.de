
package Alp3U8.Events;

import Alp3U8.Patient;
import Alp3U8.Doctor;


/**
 * ALP3 Uebung3
 * Marian Schwarz, Valentin Weckerle
 *
 * EventEndPatientTreatment represents the event that the treatment of a
 * patient has come to an end and ensures that the corresponding doctor and
 * patient object take apropriate action
 */
public class EventEndPatientTreatment extends Event
{
	private Patient p = null;
	private Doctor d = null;

	/**
	 * Constructor which sets the time, and stores the corresponding doctor and
	 * patient.
	 * @param time the time when this will happen
	 * @param d doctor that is to end treatment
	 * @param p patient that is treated.
	 */
	public EventEndPatientTreatment (int time, Doctor d, Patient p)
	{
		super (time);
		this.p = p;
		this.d = d;
	}

	/**
	 * Fire method for this event simply calls the doctor's method to end treatment
	 */
	public void fire ()
	{
		d.endTorture(p);
	}

	
	public Patient getPatient ()
	{
		return p;
	}
}
