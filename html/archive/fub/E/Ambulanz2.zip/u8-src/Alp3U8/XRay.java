
package Alp3U8;

import Alp3U8.Events.EventEndXRay;
import java.util.LinkedList;


/**
 * ALP3 Uebung3
 * Marian Schwarz, Valentin Weckerle
 *
 * XRay Class
 */
public class XRay
{
	//list of patient waiting for an xray treatment
	private LinkedList waitingRoom = null;

	//timers
	private int minXRayDuration = 5*60;
	private int maxXRayDuration = 10*60;

	private boolean busy = false;
	private int maxQueueLength = 1;

	/**
	 * initialize XRay object
	 */
	public XRay ()
	{
		waitingRoom = new LinkedList();
	}

	/**
	 * called once a new patient was send over by a doctor
	 * @param p new patient
	 */
	public void newPatient (Patient p)
	{
		Simulation.log("Patient "+p+" arrived at the XRay station, "+waitingRoom.size()+" other Patients are waiting.");

		p.startWaiting("xray");

		//if we're currently free, start this patient's treatment immediatly
		if (!busy)
			radiate(p);
		else
		{
			//ok, he might live a bit longer :o)
			waitingRoom.add(p);
			//update stats
			if (waitingRoom.size() > maxQueueLength)
				maxQueueLength= waitingRoom.size();
		}
	}

	/**
	 * select next patient in line from our xray queue and
	 * start his treatment
	 */
	public void radiateNextPatient ()
	{
		if (waitingRoom.isEmpty())
			return;

		Patient p = (Patient)waitingRoom.removeFirst();
		radiate(p);
	}

	/**
	 * called by EndXRay event to notify us that we're free to handle the next
	 * patient
	 */
	public void currentPatientLeft ()
	{
		busy = false;
	}

	/**
	 * @return max queue size seen
	 */
	public int getMaxQueueLength ()
	{
		return maxQueueLength;
	}

	/**
	 * begin this patient treatment
	 * @param p current patient
	 */
	private void radiate (Patient p)
	{
		busy = true;

		p.stopWaiting("xray");
		Simulation.log("XRay treatment of patient "+p+" has begun.");

		//ok radiate the patient
		p.wasXray();

		//create new EndXRay event to notify us (and the patient) once the treatment is over
		int duration = (int)(minXRayDuration + (maxXRayDuration - minXRayDuration)*Math.random());
		Simulation.events.insert(new EventEndXRay(Simulation.curtime + duration, p));
	}
}
