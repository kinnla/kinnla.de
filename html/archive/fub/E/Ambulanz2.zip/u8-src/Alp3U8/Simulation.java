
package Alp3U8;

import Alp3U8.Events.*;

/**
 * ALP3 Uebung8
 * Marian Schwarz, Valentin Weckerle
 *
 * Main Simulation Class
 */
public class Simulation
{
	//force patients to return to their initial doctor after xray treatment
	public static final int SIMULATION_DOCTYPE_PRIVATEDOC = 1;
	//send patients into the main reception queue
	public static final int SIMULATION_DOCTYPE_PUBLICDOC = 2;

	//allow only one xray treatment per patient
	public static final int SIMULATION_XRAYTYPE_ONLYONCE = 1;
	//allow multiple xray treatments per patient
	public static final int SIMULATION_XRAYTYPE_MULTIPLE = 2;

	//PriorityQueue which holds all pending events
	public static PQueue events;
	//1/lambda value to set average intervall between newPatient events
	public static int lambda = 0;
	//1/lambda2 value to set average intervall between newEmergPatient events
	public static int lambda2 = 0;

	//probability of leave after examination
	public static float probabilityOfLeave = 0;
	//number of active doctors
	public static int numberOfDoctors = 0;
	//time in seconds the simulation shall run
	public static int length = 0;
	//current time in seconds since start of simulation
	public static int curtime = 0;
	//SIMULATION_DOCTYPE
	public static int doctype = 0;
	//SIMULATION_XRAYTYPE
	public static int xraytype = 0;

	//reception desk, keeps main patient queue and array of doctors
	public static Reception receptionDesk = null;
	//xray with own patient queue
	public static XRay xray = null;

	//stat counters
	private static int patientCount = 0;
	private static int maxPatientWaitTime = 0;
	private static long patientWaitTime = 0;
	private static int docWaitTime = 0;
	private static int maxRadiationLevel = 0;

	private static int emergReturnCounter = 0;

	/**
	 * Initializes the Simulation Object
	 * @param lambda average time between newPatient events in seconds
	 * @param p probability of leave after examination
	 * @param n number of active doctors
	 * @param length time in seconds the simulation shall run
	 * @param doctype SIMULATION_DOCTYPE
	 * @param xraytype SIMULATION_XRAYTYPE
	 */
	public Simulation (int lambda, int lambda2, float p, int n, int length, int doctype, int xraytype)
	{
		events = new Heap();

		this.lambda = lambda;
		this.lambda2 = lambda2;
		this.probabilityOfLeave = p;
		this.numberOfDoctors = n;
		this.length = length;
		this.doctype = doctype;
		this.xraytype = xraytype;

		receptionDesk = new Reception();
		xray = new XRay();
	}

	/**
	 * Run the simulation, this method will handle all events untill the event queue is emptied.
	 * After all events have been handled additional statistics are printed.
	 */
	public void run ()
	{
		//begin simulation
		log("----- Begin of Simulation -----");

		//insert first patientEvent, this will spawn our first patient at time = 0s
		//and will also generate further newPatient events until the office hours are over
		events.insert(new EventNewPatient(0));

		//insert first emergPatientEvent
		events.insert(new EventNewEmergPatient((int)(-1 * Simulation.lambda2 * Math.log( Math.random()))));

		//handle next pending event untill event queue is empty
		while (!events.isEmpty())
		{
			Event e = (Event)events.removeMin();
			//check for validness and skip invalidated events
			if (!e.isValid())
				continue;
			//update current time
			curtime = e.getTime();
			//handle event
			e.fire();
			System.out.println("----------");
		}

		//end of simulation
		log("----- End of Simulation -----");

		//print stats
		statPrint();
	}

	/**
	 * called once a patient leaves the ambulance to enable us to keep track
	 * of the statistics.
	 * @param p patient which left
	 */
	public static void statPatientLeft (Patient p)
	{
		if (p.isEmerg())
		{
			emergReturnCounter++;
			if (emergReturnCounter == numberOfDoctors)
				emergReturnCounter = 0;
			else
				return;
		}
		//check if this patient has set a new maxPatientWaitTime record, if so, update stats
		patientWaitTime += p.getWaitingTime();
		if (p.getWaitingTime() > maxPatientWaitTime)
			maxPatientWaitTime = p.getWaitingTime();

		//check if this patient set a new maxRadiationLevel record
		if (p.getRadiationLevel() > maxRadiationLevel)
			maxRadiationLevel = p.getRadiationLevel();

		patientCount++;

		log("patient left: "+p+", after: "+formatTime(Simulation.curtime - p.getBeginVisit())+", waitingtime: "+formatTime(p.getWaitingTime())+", radiationlevel: "+p.getRadiationLevel());
		//uncomment the following line to enable patient file output on patient leave
		System.out.println("\n"+p.getPatientFile()+"\n");
	}

	/**
	 * called once every time a doctor stops playing pool to keep track of the doctor waiting time
	 * @param time time in seconds the doctor played pool
	 */
	public static void statDocWaited (int time)
	{
		docWaitTime += time;
	}

	/**
	 * prints statistic counters
	 */
	public static void statPrint ()
	{
		System.out.println("Duration: "+formatTime(Simulation.curtime));
		System.out.println("Patients: "+patientCount);
		System.out.println("MaxPatientWaitingTime: "+formatTime(maxPatientWaitTime));
		System.out.println("AvgPatientWaitingTime: "+ formatTime((int)(patientWaitTime/patientCount)) );
		System.out.println("MaxRadiationLevel: "+maxRadiationLevel);

		//check if we handled all patients while still within office hours, in that case
		//add the time between the last doc visit and the end time.
		int docWaitOffset = 0;
		if (Simulation.curtime < Simulation.length)
			docWaitOffset = Simulation.length - Simulation.curtime;
		System.out.println("DoctorWaitingTime: "+formatTime(docWaitTime + docWaitOffset));

		System.out.println("MaxReceptionQueueLength: "+receptionDesk.getMaxQueueLength());
		System.out.println("MaxPersonalQueueLength: "+receptionDesk.getMaxPersonalQueueLength());
		System.out.println("MaxXRayQueueLength: "+xray.getMaxQueueLength());
	}

	/**
	 * converts a time value from seconds into a formated string of the form hh:mm:ss
	 * @param time time in seconds to convert
	 * @return string of the form hh:mm:ss
	 */
	public static String formatTime (int time)
	{
		int h = time/60/60;
		time -= h*60*60;
		int m = time/60;
		time -= m*60;
		int s = time;

		return toStr(h)+":"+toStr(m)+":"+toStr(s);
	}

	/**
	 * print log message to stdout and add the current time to the entry
	 * @param msg
	 */
	public static void log (String msg)
	{
		System.out.println("["+formatTime(curtime+7*60*60)+"] "+msg);
	}

	/**
	 * used internally by formatTime, padds a given number with a leading 0 if it is
	 * < 10
	 * @param d number
	 * @return padded number
	 */
	private static String toStr (int d)
	{
		if (d < 10)
			return "0"+d;
		else
			return Integer.toString(d);
	}
}
