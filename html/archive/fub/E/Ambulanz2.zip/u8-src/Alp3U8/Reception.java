
package Alp3U8;

import java.util.LinkedList;
import java.util.NoSuchElementException;


/**
 * ALP3 Uebung8
 * Marian Schwarz, Valentin Weckerle
 *
 * Reception Class
 */
public class Reception
{
	//main queue for patient
	private LinkedList waitingRoom = null;
	//queue for emergency patients
	private LinkedList emergWaitingRoom = null;
	//patient number sequence which is used to assign a unique id to each new patient
	private int patientNumberSequence = 1;
	//array of active doctors
	private Doctor[] staffRoom = null;
	//store emergency status
	private boolean emergencyInProgress = false;
	private int maxQueueLength = 0;
	private int maxEmergQueueLength = 0;
	//the end of an emergency patient treatment is announced three times, once by
	//each doctor, we need to keep track of the number of doctors which have already
	//announced that they're ready again
	private int emergReturnCount = 0;

	/**
	 * initialize the reception object
	 * new doctors are spawned
	 */
	public Reception ()
	{
		waitingRoom = new LinkedList();
		emergWaitingRoom = new LinkedList();

		//populate staff room
		staffRoom = new Doctor[Simulation.numberOfDoctors];
		for (int i=0; i < staffRoom.length; i++)
		{
			staffRoom[i] = new Doctor(i+1);
		}
	}

	/**
	 * called once a new patient arrives at the reception desk, depending on the current mode of
	 * the simulation those are either only the new patients or also those who return from the
	 * xray treatment
	 * @param p new patient
	 */
	public void newPatient (Patient p)
	{
		//check if known patient
		if (p.getPatId() == 0)
		{
			//brand new victim
			p.givePatientNumber(patientNumberSequence++);

			Simulation.log("New Patient "+p+" arrived at the reception desk, "+waitingRoom.size()+" other Patients are waiting.");
		}

		//check if the patient will be the only one in the waitingRoom
		boolean isOnlyPatient = waitingRoom.isEmpty();

		waitingRoom.add(p);
		p.startWaiting("doctor");

		//update stats
		if (waitingRoom.size() > maxQueueLength)
			maxQueueLength = waitingRoom.size();

		//ok, the waiting room was empty before this patient showed up
		//it's very likely that all our doctors are playing pool in the
		//staff room, so we'll have to kick some butt :o)
		if (isOnlyPatient)
		{
			Doctor lameass = getNextLameass();
			kick(lameass);
			/*
				Hier k�nnte man nat�rlich argumentieren, dass ein lameass
				seine kick routine selber mitbringen sollte.
				Nach reichlicher �berlegung haben wir uns jedoch dazu entschlossen
				diese anspruchsvolle aufgabe dem rezeptionspersonal zu �berlassen :o)
			*/
		}
	}

	/**
	 * called once a new emergency patient arrives at the reception desk
	 * emergency patients are queued in a special emergency queue and each patient
	 * is instantly delegated to the doctors once they're not handling any other
	 * emergency patient
	 * @param p new emergency patient
	 */
	public void newEmergPatient (Patient p)
	{
		//check if known patient
		if (p.getPatId() == 0)
		{
			//brand new victim
			p.givePatientNumber(patientNumberSequence++);

			Simulation.log("New EMERGENCY Patient "+p+" arrived at the reception desk, "+emergWaitingRoom.size()+" other EMERGENCY Patients are waiting.");
		}

		//check if the patient will be the only one in the waitingRoom
		boolean isOnlyPatient = emergWaitingRoom.isEmpty();

		emergWaitingRoom.add(p);
		p.startWaiting("doctor");

		//update stats
		if (emergWaitingRoom.size() > maxEmergQueueLength)
			maxEmergQueueLength = emergWaitingRoom.size();

		//ok, the waiting room was empty before this patient showed up
		//it's very likely that all our doctors are torturing lesser patients atm
		//or might even play pool
		if ( isOnlyPatient && (!emergencyInProgress) )
		{
			//switch to emergency state
			emergencyInProgress = true;
			//remove emergency patient from queue
			emergWaitingRoom.remove(p);
			//notify all doctors
			emergNotifyToDoctors(p);
		}
	}

	/**
	 * called by all doctors once an emergency treatment ended
	 * will check the emergency queue to issue new emergency notifications if more
	 * emerg. patients are waiting
	 */
	public void emergTreatmentEnded ()
	{
		//wait for all doctors to return
		emergReturnCount++;

		if (emergReturnCount == Simulation.numberOfDoctors)
		{
			//reset emergency state
			emergencyInProgress = false;
			emergReturnCount = 0;

			//check if new emerg. patients are waiting
			if (!emergWaitingRoom.isEmpty())
			{
				//yes, we have more emerg. patients
				Patient p = (Patient)emergWaitingRoom.removeFirst();
				//switch to emergency state
				emergencyInProgress = true;
				//notify all doctors
				emergNotifyToDoctors(p);
			}
		}
	}

	/**
	 * returns the next waiting patient from the main queue and removes it from the queue
	 * @return next patient in line or null if queue is empty
	 */
	public Patient getNextPatient ()
	{
		try
		{
			return (Patient)waitingRoom.removeFirst();
		}
		catch (NoSuchElementException e)
		{
			return null;
		}
	}

	/**
	 * @return highest queue length seen
	 */
	public int getMaxQueueLength ()
	{
		return maxQueueLength;
	}

	/**
	 * checks all doctors and returns the highest personal queue length found
	 * @return highest personal queue length
	 */
	public int getMaxPersonalQueueLength ()
	{
		int max = 0;

		for(int i=0; i < staffRoom.length; i++)
			if (staffRoom[i].getMaxQueueLength() > max)
				max = staffRoom[i].getMaxQueueLength();

		return max;
	}

	/**
	 * @return number of patients waiting
	 */
	public int getWaitingRoomSize ()
	{
		return waitingRoom.size();
	}

	/**
	 * check the staff room for pool playing doctors and pick one
	 * @return first idle doctor found or null if all doctors are busy
	 */
	private Doctor getNextLameass ()
	{
		for(int i=0; i < staffRoom.length; i++)
			if (staffRoom[i].isPlayingPool())
				return staffRoom[i];

		return null;
	}

	/**
	 * called by the reception to notify all doctors that they should
	 * halt the treatment of their current patient and should
	 * start to treat the new emergency patient
	 * @param p new emergency patient
	 */
	private void emergNotifyToDoctors (Patient p)
	{
		//calc the time needed for this emergency
		int duration = (int)(30*60+(10*60)*Math.random());

		//notify all doctors
		for(int i=0; i < staffRoom.length; i++)
			staffRoom[i].newEmergVictim(p, duration);
	}

	/**
	 * tell a given pool playing lameass to get moving and do his job
	 * @param lameass idle doctor
	 */
	private void kick (Doctor lameass)
	{
		if (lameass != null)
			lameass.endPoolGame(true);
		//else
		//WTF? no one playing pool? something must be broken! ;o)
	}
}
