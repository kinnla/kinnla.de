
import Alp3U8.Simulation;


/**
 * ALP3 Uebung8
 * Marian Schwarz, Valentin Weckerle
 *
 * Doctor Class
 */
public class Alp3U8
{
	/**
	 * main method for testing/debuging only
	 * @param args
	 */
	public static void main (String[] args)
	{
		//initialize the simulation
		Simulation s = new Simulation(12*60, 2*60*60, 0.15f, 3, 4*60*60, Simulation.SIMULATION_DOCTYPE_PRIVATEDOC, Simulation.SIMULATION_XRAYTYPE_ONLYONCE);
		//start the simulation
		s.run();
	}
}
